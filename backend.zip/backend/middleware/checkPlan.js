import User from '../models/User.js';

export const checkPlan = (requiredPlan) => {
  return async (req, res, next) => {
    try {
      const user = await User.findById(req.user.userId);
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Allow premium users to access all features
      if (user.plan === 'premium') {
        return next();
      }

      // Check if the user's plan matches the required plan
      if (requiredPlan === 'starter' && user.plan === 'starter') {
        return next();
      }

      // If we get here, the user doesn't have access
      return res.status(403).json({
        error: 'Feature not available in your current plan',
        upgrade: true,
        currentPlan: user.plan,
        requiredPlan: requiredPlan
      });
    } catch (error) {
      return res.status(500).json({ error: 'Error checking plan access' });
    }
  };
};

export const isPremium = (req, res, next) => {
  return checkPlan('premium')(req, res, next);
};

export const isStarter = (req, res, next) => {
  return checkPlan('starter')(req, res, next);
};

export default {
  checkPlan,
  isPremium,
  isStarter
}; 