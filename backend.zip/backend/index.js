// Load environment variables
import dotenv from 'dotenv';

dotenv.config({
  path: './.env'
});
import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import multer from 'multer';
import { createServer } from 'http';
import session from 'express-session';
import MongoStore from 'connect-mongo';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import compression from 'compression';
import morgan from 'morgan';
import { fileURLToPath } from 'url';
import path from 'path';

// Configurations
import { initSocket } from './config/socket.js';
import { sessionConfig } from './config/auth.js';
import { initCronJobs } from './config/cron.js';

// Models
import UserScore from './models/UserScore.js';

// Routes
import authRoutes from './routes/auth.js';
import adminRoutes from './routes/admin.js';
import securityRoutes from './routes/security.js';
import paymentRoutes from './routes/payment.js';

// Middleware
import { auth } from './middleware/auth.js';
import { rateLimiter } from './middleware/rateLimiter.js';

const app = express();
const httpServer = createServer(app);

// Initialize WebSocket
const io = initSocket(httpServer);

// Environment variables
const PORT = process.env.PORT || 3001;
const NODE_ENV = process.env.NODE_ENV || 'development';
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173';

// Security middleware
app.use(helmet());
app.use(compression());

// Logging
if (NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// CORS configuration
app.use(cors({
  origin: FRONTEND_URL,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// MongoDB Connection
const MONGODB_URI = process.env.MONGODB_URI;
if (!MONGODB_URI) {
  throw new Error('MONGODB_URI is required');
}

mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
  .then(() => {
    console.log('✅ MongoDB connected successfully');
    
    // Session configuration - after MongoDB connection
    app.use(session({
      ...sessionConfig,
      store: MongoStore.create({
        client: mongoose.connection.getClient(),
        collectionName: 'sessions'
      })
    }));

    // Rate limiting configuration
    const limiter = rateLimit({
      windowMs: parseInt(process.env.RATE_LIMIT_WINDOW) * 1000 || 15000, // 15 seconds
      max: parseInt(process.env.RATE_LIMIT_MAX) || 100,
      message: 'Too many requests from this IP, please try again later.',
      standardHeaders: true,
      legacyHeaders: false
    });

    // Apply rate limiting to public routes only
    app.use('/api', limiter);
    app.use('/api/auth', limiter);

    // Request body parsing
    app.use(express.json({ limit: '50mb' }));
    app.use(express.urlencoded({ extended: true, limit: '50mb' }));

    // Configure multer for file uploads with size limits
    const storage = multer.memoryStorage();
    const upload = multer({
      storage: storage,
      limits: {
        fileSize: parseInt(process.env.MAX_FILE_SIZE) || 5242880, // 5MB
      },
      fileFilter: (req, file, cb) => {
        const allowedTypes = process.env.ALLOWED_FILE_TYPES?.split(',') || ['image/jpeg', 'image/png', 'application/pdf'];
        if (allowedTypes.includes(file.mimetype)) {
          cb(null, true);
        } else {
          cb(new Error('File type not supported'));
        }
      }
    });

    // Routes
    app.use('/api', authRoutes);
    app.use('/api/admin', auth, adminRoutes);
    app.use('/api/security', auth, securityRoutes);
    app.use('/api/payments', auth, paymentRoutes);

    // Protected test route
    app.get('/api/test', auth, (req, res) => {
      res.json({ message: 'Backend is working!', user: req.user });
    });

    // Protected test email route
    app.post('/api/test-email', auth, async (req, res) => {
      try {
        const { sendEmail, emailTemplates } = await import('./config/email.js');
        
        // Use user's email instead of hardcoded one
        await sendEmail({
          to: req.user.email,
          ...emailTemplates.welcomeEmail(req.user.username)
        });

        res.json({ message: 'Test email sent successfully!' });
      } catch (error) {
        console.error('Email error:', error);
        res.status(500).json({ error: 'Failed to send test email', details: error.message });
      }
    });

    // File upload route
    app.post('/api/upload-credit-data', auth, upload.single('file'), async (req, res) => {
      try {
        if (!req.file) {
          return res.status(400).json({ error: 'No file uploaded' });
        }

        // Process the uploaded file here
        res.json({ message: 'File uploaded successfully', file: req.file });
      } catch (error) {
        console.error('Upload error:', error);
        res.status(500).json({ error: 'Failed to upload file', details: error.message });
      }
    });

    // Error handling middleware
    app.use((err, req, res, next) => {
      console.error(err.stack);
      res.status(err.status || 500).json({
        error: err.message,
        details: process.env.NODE_ENV === 'development' ? err.stack : undefined
      });
    });

    // Simulated bureau API integration with WebSocket updates
    app.post('/api/update-from-bureau', auth, async (req, res) => {
      try {
        const { creditData } = req.body;
        if (!creditData || !creditData.score) {
          return res.status(400).json({ error: 'Invalid credit data' });
        }

        const updatedScore = await UserScore.findOneAndUpdate(
          { userId: req.user.userId },
          {
            $set: {
              score: creditData.score,
              factors: creditData.factors || [],
              history: [
                ...(creditData.history || []),
                { score: creditData.score, date: new Date() }
              ]
            }
          },
          { new: true }
        );

        // Emit score update via WebSocket
        io.to(`user_${req.user.userId}`).emit('scoreUpdate', {
          score: updatedScore.score,
          factors: updatedScore.factors
        });

        res.json({ message: 'Credit score updated successfully' });
      } catch (error) {
        console.error('Error updating credit score:', error);
        res.status(500).json({ error: 'Failed to update credit score' });
      }
    });

    // Get credit score
    app.get('/api/credit-score/:userId', auth, async (req, res) => {
      try {
        const data = await UserScore.findOne({ userId: req.params.userId });
        if (!data) {
          const defaultScore = new UserScore({
            userId: req.params.userId,
            score: 650,
            factors: [
              { name: 'Payment History', weight: 35 },
              { name: 'Credit Utilization', weight: 30 },
              { name: 'Credit History Length', weight: 15 },
              { name: 'New Credit', weight: 10 },
              { name: 'Credit Mix', weight: 10 }
            ]
          });
          await defaultScore.save();
          return res.json(defaultScore);
        }
        res.json(data);
      } catch (error) {
        console.error('Error fetching credit score:', error);
        res.status(500).json({ error: 'Failed to fetch credit score' });
      }
    });

    // Update credit score
    app.put('/api/credit-score/:userId', auth, async (req, res) => {
      try {
        const { score, factors, history } = req.body;
        if (!score) {
          return res.status(400).json({ error: 'Score is required' });
        }

        const updatedScore = await UserScore.findOneAndUpdate(
          { userId: req.params.userId },
          {
            $set: {
              score,
              factors: factors || [],
              history: [
                ...(history || []),
                { score, date: new Date() }
              ]
            }
          },
          { new: true }
        );

        if (!updatedScore) {
          return res.status(404).json({ error: 'User not found' });
        }

        // Emit score update via WebSocket
        io.to(`user_${req.params.userId}`).emit('scoreUpdate', {
          score: updatedScore.score,
          factors: updatedScore.factors
        });

        res.json({ message: 'Credit score updated successfully' });
      } catch (error) {
        console.error('Error updating credit score:', error);
        res.status(500).json({ error: 'Failed to update credit score' });
      }
    });
});

// Start server
httpServer.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`Environment: ${NODE_ENV}`);
  console.log(`Frontend URL: ${FRONTEND_URL}`);

  // Initialize cron jobs
  initCronJobs();
});

// ... (rest of the code remains the same)

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server');
  httpServer.close(() => {
    console.log('HTTP server closed');
    mongoose.connection.close(() => {
      console.log('MongoDB connection closed');
      process.exit(0);
    });
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT signal received: closing HTTP server');
  httpServer.close(() => {
    console.log('HTTP server closed');
    mongoose.connection.close(() => {
      console.log('MongoDB connection closed');
      process.exit(0);
    });
  });
});
