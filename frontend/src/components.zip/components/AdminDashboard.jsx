import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { 
  Users, 
  CreditCard, 
  History, 
  UserPlus, 
  Upload,
  AlertCircle,
  User
} from 'lucide-react';

// UI Components
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { useToast } from '../hooks/use-toast';
import { Skeleton } from './ui/skeleton';

// Custom Components
import RegisterUser from './admin/RegisterUser';
import AdminBatchUpload from './AdminBatchUpload';
import UploadHistory from './admin/UploadHistory';
import UserDataViewer from './admin/UserDataViewer';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../lib/api';

const AdminDashboard = () => {
  console.log('Rendering AdminDashboard');
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user, logout } = useAuth();
  
  // Debug: Log user info
  useEffect(() => {
    console.log('AdminDashboard - User:', user);
    console.log('AdminDashboard - User role:', user?.role);
  }, [user]);
  
  // State
  const [activeTab, setActiveTab] = useState('users');
  const [users, setUsers] = useState([]);
  const [creditReports, setCreditReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showRegisterUser, setShowRegisterUser] = useState(false);
  const [showBatchUpload, setShowBatchUpload] = useState(false);
  const [error, setError] = useState(null);

  // Fetch users
  const fetchUsers = useCallback(async () => {
    try {
      setLoading(true);
      const response = await api.get('/admin/users');
      setUsers(response.data);
    } catch (err) {
      console.error('Error fetching users:', err);
      setError('Failed to fetch users');
      
      if (err.response?.status === 401 || err.response?.status === 403) {
        toast({
          title: 'Session expired',
          description: 'Please log in again',
          variant: 'destructive',
        });
        logout();
        navigate('/login');
      }
    } finally {
      setLoading(false);
    }
  }, [navigate, logout, toast]);

  // Fetch credit reports
  const fetchCreditReports = useCallback(async () => {
    try {
      setLoading(true);
      const response = await api.get('/admin/credit-reports');
      setCreditReports(response.data);
    } catch (err) {
      console.error('Error fetching credit reports:', err);
      setError('Failed to fetch credit reports');
      
      if (err.response?.status === 401 || err.response?.status === 403) {
        toast({
          title: 'Session expired',
          description: 'Please log in again',
          variant: 'destructive',
        });
        logout();
        navigate('/login');
      }
    } finally {
      setLoading(false);
    }
  }, [navigate, logout, toast]);

  // Initial data fetch
  useEffect(() => {
    if (activeTab === 'users') {
      fetchUsers();
    } else if (activeTab === 'credit-reports') {
      fetchCreditReports();
    }
  }, [activeTab, fetchUsers, fetchCreditReports]);

  // Handle batch upload completion
  const handleUploadComplete = useCallback((uploadData) => {
    console.log('Batch upload completed:', uploadData);
    
    // Refresh the appropriate data based on current tab
    if (activeTab === 'users') {
      fetchUsers();
    } else if (activeTab === 'credit-reports') {
      fetchCreditReports();
    }
    
    toast({
      title: 'Upload Complete',
      description: `Successfully processed ${uploadData.successCount} records`,
    });
  }, [activeTab, fetchUsers, fetchCreditReports, toast]);

  // Loading state
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px]">
        <div className="animate-spin h-16 w-16 border-t-4 border-b-4 border-blue-500 rounded-full mb-4"></div>
        <p className="text-gray-600 dark:text-gray-400">Loading dashboard...</p>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="bg-red-50 dark:bg-red-900/20 p-6 rounded-lg">
        <div className="flex items-center gap-4">
          <AlertCircle className="h-6 w-6 text-red-500" />
          <div>
            <h3 className="text-lg font-medium text-red-800 dark:text-red-200">Error</h3>
            <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
            <Button 
              variant="outline" 
              className="mt-2"
              onClick={activeTab === 'users' ? fetchUsers : fetchCreditReports}
            >
              Retry
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
          <p className="text-muted-foreground">
            Manage users, credit reports, and system settings
          </p>
        </div>
        <div className="flex items-center space-x-2">
          {activeTab === 'users' && (
            <>
              <Button onClick={() => setShowRegisterUser(true)}>
                <UserPlus className="mr-2 h-4 w-4" />
                Add User
              </Button>
              <Button variant="outline" onClick={() => setShowBatchUpload(true)}>
                <Upload className="mr-2 h-4 w-4" />
                Batch Upload
              </Button>
            </>
          )}
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="users">
            <Users className="mr-2 h-4 w-4" />
            Users
          </TabsTrigger>
          <TabsTrigger value="credit-reports">
            <CreditCard className="mr-2 h-4 w-4" />
            Credit Reports
          </TabsTrigger>
          <TabsTrigger value="upload-history">
            <History className="mr-2 h-4 w-4" />
            Upload History
          </TabsTrigger>
          <TabsTrigger value="user-data">
            <User className="mr-2 h-4 w-4" />
            User Data
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Users</CardTitle>
                  <CardDescription>
                    Manage system users and their permissions
                  </CardDescription>
                </div>
                <div className="flex items-center space-x-2">
                  <Button onClick={() => setShowRegisterUser(true)}>
                    <UserPlus className="mr-2 h-4 w-4" />
                    Add User
                  </Button>
                  <Button variant="outline" onClick={() => setShowBatchUpload(true)}>
                    <Upload className="mr-2 h-4 w-4" />
                    Batch Upload
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Login</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user._id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                          {user.role}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.active ? 'default' : 'outline'}>
                          {user.active ? 'Active' : 'Inactive'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {user.lastLogin ? format(new Date(user.lastLogin), 'PPpp') : 'Never'}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          Edit
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="credit-reports">
          <Card>
            <CardHeader>
              <CardTitle>Credit Reports</CardTitle>
              <CardDescription>
                View and manage user credit reports
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Updated</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {creditReports.map((report) => (
                    <TableRow key={report._id}>
                      <TableCell className="font-medium">
                        {report.user?.name || 'N/A'}
                      </TableCell>
                      <TableCell>{report.score}</TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {report.status || 'Pending'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {format(new Date(report.updatedAt), 'PPpp')}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          View Details
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upload-history">
          <UploadHistory />
        </TabsContent>

        <TabsContent value="user-data">
          <Card>
            <CardHeader>
              <CardTitle>User Credit Data</CardTitle>
              <CardDescription>
                View detailed credit information for any user
              </CardDescription>
            </CardHeader>
            <CardContent>
              <UserDataViewer />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Modals */}
      <RegisterUser 
        open={showRegisterUser} 
        onOpenChange={setShowRegisterUser}
        onSuccess={() => {
          fetchUsers();
          setShowRegisterUser(false);
        }}
      />

      <AdminBatchUpload 
        open={showBatchUpload}
        onOpenChange={setShowBatchUpload}
        onUploadComplete={handleUploadComplete}
      />
    </div>
  );
};

export default AdminDashboard;
