import speakeasy from 'speakeasy';
import qrcode from 'qrcode';
import session from 'express-session';
import jwt from 'jsonwebtoken';

// Session configuration
export const sessionConfig = {
  secret: process.env.SESSION_SECRET || 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
};

// Generate secret for 2FA
export const generateTwoFactorSecret = async (email) => {
  const secret = speakeasy.generateSecret({
    name: `Credit Score Dashboard (${email})`
  });

  const qrCodeUrl = await qrcode.toDataURL(secret.otpauth_url);

  return {
    secret: secret.base32,
    qrCode: qrCodeUrl
  };
};

// Verify 2FA token
export const verifyTwoFactorToken = (secret, token) => {
  return speakeasy.totp.verify({
    secret,
    encoding: 'base32',
    token
  });
};

// Generate JWT token
export const generateToken = (user) => {
  return jwt.sign(
    { userId: user._id },
    process.env.JWT_SECRET || 'your-secret-key',
    { expiresIn: '24h' }
  );
};

export default {
  sessionConfig,
  generateTwoFactorSecret,
  verifyTwoFactorToken,
  generateToken
}; 