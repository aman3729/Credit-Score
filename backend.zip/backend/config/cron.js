import cron from 'node-cron';
import User from '../models/User.js';
import Payment from '../models/Payment.js';
import { sendEmail, emailTemplates } from './email.js';
import { logArchiver } from '../services/logArchiver.js';
import { logger } from './logger.js';

// Run daily at midnight
export const initCronJobs = () => {
  // Subscription management cron
  cron.schedule('0 0 * * *', async () => {
    try {
      // Find users whose subscriptions are due for renewal in 3 days
      const threeDaysFromNow = new Date();
      threeDaysFromNow.setDate(threeDaysFromNow.getDate() + 3);
      
      const usersToRenew = await User.find({
        'planDetails.nextBillingDate': {
          $gte: new Date(),
          $lte: threeDaysFromNow
        },
        'planDetails.status': 'active'
      });

      // Send renewal reminders
      for (const user of usersToRenew) {
        const lastPayment = await Payment.findOne({ 
          userId: user._id,
          status: 'completed'
        }).sort({ completedAt: -1 });

        if (lastPayment) {
          await sendEmail({
            to: user.email,
            ...emailTemplates.subscriptionRenewal(
              user.username,
              user.plan,
              lastPayment.amount,
              user.planDetails.nextBillingDate
            )
          });
        }
      }

      // Find expired subscriptions
      const expiredUsers = await User.find({
        'planDetails.nextBillingDate': { $lt: new Date() },
        'planDetails.status': 'active'
      });

      // Update expired subscriptions
      for (const user of expiredUsers) {
        user.planDetails.status = 'past_due';
        await user.save();

        // Send expiration notification
        await sendEmail({
          to: user.email,
          subject: 'Subscription Expired - Credit Score Dashboard',
          html: `
            <h1>Subscription Expired</h1>
            <p>Hello ${user.username},</p>
            <p>Your ${user.plan} plan subscription has expired.</p>
            <p>Please renew your subscription to continue accessing premium features.</p>
          `
        });
      }
    } catch (error) {
      logger.error('Subscription cron job error:', error);
    }
  });

  // Log archiving cron - runs daily at 1 AM
  cron.schedule('0 1 * * *', async () => {
    try {
      await logArchiver.archiveOldLogs();
      logger.info('Successfully completed log archiving');
    } catch (error) {
      logger.error('Log archiving cron job error:', error);
    }
  });

  // S3 cleanup cron - runs monthly
  cron.schedule('0 0 1 * *', async () => {
    try {
      await logArchiver.cleanupOldArchives();
      logger.info('Successfully cleaned up old archived logs');
    } catch (error) {
      logger.error('S3 cleanup cron job error:', error);
    }
  });
}; 