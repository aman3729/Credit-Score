import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Card, Table, Tag, message, Descriptions, Divider, Button, Badge, Tooltip } from 'antd';
import { 
  UserOutlined, 
  MailOutlined, 
  CalendarOutlined, 
  ArrowUpOutlined, 
  ArrowDownOutlined,
  InfoCircleOutlined
} from '@ant-design/icons';
import api from '../../utils/api';

const formatDate = (dateString) => {
  if (!dateString) return 'N/A';
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch (e) {
    console.error('Error formatting date:', e);
    return 'Invalid date';
  }
};

const LenderCreditDataViewer = () => {
  const { userId } = useParams();
  const [userData, setUserData] = useState({
    user: null,
    creditScores: [],
    currentScore: null,
    factors: []
  });
  const [loading, setLoading] = useState(true);
  const [decision, setDecision] = useState(null);
  const [decisionLoading, setDecisionLoading] = useState(false);

  const fetchUserData = async () => {
    if (!userId) {
      message.warning('No user ID provided');
      return;
    }

    try {
      setLoading(true);
      const response = await api.get(`/users/${userId}/credit-data`);
      
      // Transform the data to match our expected format
      const transformedData = {
        user: response.data.data.user,
        currentScore: response.data.data.currentScore,
        creditScores: response.data.data.creditScores || [],
        factors: response.data.data.factors || []
      };
      
      setUserData(transformedData);
    } catch (error) {
      console.error('Error fetching user data:', error);
      message.error(error.response?.data?.error || 'Failed to fetch user data');
    } finally {
      setLoading(false);
    }
  };

  const makeLendingDecision = async () => {
    if (!userId) return;
    
    try {
      setDecisionLoading(true);
      // In a real app, you would make an API call to get a lending decision
      // const response = await api.post(`/lender/decide`, { userId });
      // setDecision(response.data);
      
      // Mock decision for demo
      setTimeout(() => {
        setDecision({
          approved: userData.currentScore >= 650,
          interestRate: userData.currentScore >= 750 ? 5.9 : 
                        userData.currentScore >= 700 ? 7.5 :
                        userData.currentScore >= 650 ? 10.9 : null,
          maxAmount: userData.currentScore >= 750 ? 50000 : 
                    userData.currentScore >= 700 ? 30000 :
                    userData.currentScore >= 650 ? 15000 : 0,
          reason: userData.currentScore >= 650 ? 
                 'Good credit score. Eligible for loan.' :
                 'Credit score below minimum requirement.'
        });
        setDecisionLoading(false);
      }, 1000);
      
    } catch (error) {
      console.error('Error making lending decision:', error);
      message.error('Failed to make lending decision');
      setDecisionLoading(false);
    }
  };

  useEffect(() => {
    fetchUserData();
  }, [userId]);

  const columns = [
    {
      title: 'Date',
      dataIndex: 'date',
      key: 'date',
      render: (date) => formatDate(date),
      sorter: (a, b) => new Date(a.date || 0) - new Date(b.date || 0),
      defaultSortOrder: 'descend',
      width: 200,
    },
    {
      title: 'Score',
      dataIndex: 'score',
      key: 'score',
      render: (score) => {
        if (score === undefined || score === null) return 'N/A';
        const displayScore = Math.min(Math.round(score), 999);
        const color = score >= 700 ? '#52c41a' : score >= 600 ? '#faad14' : '#f5222d';
        
        return (
          <div className="flex items-center">
            <div 
              style={{
                backgroundColor: color,
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontWeight: 'bold',
                marginRight: '8px'
              }}
            >
              {displayScore}
            </div>
            <div>
              <div className="font-medium">{displayScore}</div>
              <div className="text-xs text-gray-500">
                {score >= 700 ? 'Excellent' : score >= 600 ? 'Good' : 'Needs Improvement'}
              </div>
            </div>
          </div>
        );
      },
      sorter: (a, b) => (a.score || 0) - (b.score || 0),
      width: 200,
    },
    {
      title: 'Change',
      key: 'change',
      render: (_, record, index) => {
        if (index === 0 || !userData.creditScores?.[index - 1]?.score) return 'N/A';
        const change = record.score - userData.creditScores[index - 1].score;
        const isPositive = change >= 0;
        const changeText = isPositive ? `+${change}` : change;
        
        return (
          <span className={`inline-flex items-center ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
            {isPositive ? (
              <ArrowUpOutlined className="mr-1" />
            ) : (
              <ArrowDownOutlined className="mr-1" />
            )}
            {changeText} pts
          </span>
        );
      },
      width: 150,
    },
    {
      title: 'Status',
      key: 'status',
      render: (_, record) => {
        const score = record.score || 0;
        let status, color;
        
        if (score >= 700) {
          status = 'Excellent';
          color = 'success';
        } else if (score >= 600) {
          status = 'Good';
          color = 'warning';
        } else {
          status = 'Needs Improvement';
          color = 'error';
        }
        
        return <Tag color={color} className="capitalize">{status}</Tag>;
      },
      filters: [
        { text: 'Excellent (700+)', value: 'excellent' },
        { text: 'Good (600-699)', value: 'good' },
        { text: 'Needs Improvement (<600)', value: 'needs_improvement' },
      ],
      onFilter: (value, record) => {
        const score = record.score || 0;
        if (value === 'excellent') return score >= 700;
        if (value === 'good') return score >= 600 && score < 700;
        return score < 600;
      },
      width: 180,
    },
  ];

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* User Information */}
        <Card title="Borrower Information" className="col-span-1">
          <div className="space-y-4">
            <div>
              <div className="text-sm text-gray-500">Name</div>
              <div className="font-medium flex items-center">
                <UserOutlined className="mr-2" />
                {userData.user?.name || <span className="text-gray-400">Not provided</span>}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Email</div>
              <div className="flex items-center">
                <MailOutlined className="mr-2" />
                {userData.user?.email || <span className="text-gray-400">Not provided</span>}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Member Since</div>
              <div className="flex items-center">
                <CalendarOutlined className="mr-2" />
                {userData.user?.createdAt ? formatDate(userData.user.createdAt) : 'N/A'}
              </div>
            </div>
          </div>
        </Card>

        {/* Credit Score Summary */}
        <Card 
          title={
            <div className="flex items-center">
              <span>Credit Score</span>
              <Tooltip title="Based on the most recent credit report">
                <InfoCircleOutlined className="ml-2 text-gray-400" />
              </Tooltip>
            </div>
          } 
          className="col-span-1"
        >
          {userData.currentScore !== undefined && userData.currentScore !== null ? (
            <div className="text-center">
              <div 
                className="mx-auto w-32 h-32 rounded-full flex items-center justify-center text-white text-3xl font-bold mb-4"
                style={{
                  background: `linear-gradient(135deg, ${userData.currentScore >= 700 ? '#52c41a' : userData.currentScore >= 600 ? '#faad14' : '#f5222d'}, ${userData.currentScore >= 700 ? '#73d13d' : userData.currentScore >= 600 ? '#ffc53d' : '#ff4d4f'})`,
                  boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
                }}
              >
                {Math.round(userData.currentScore)}
              </div>
              <div className="text-lg font-medium mb-2">
                {userData.currentScore >= 700 ? 'Excellent' : userData.currentScore >= 600 ? 'Good' : 'Needs Improvement'}
              </div>
              <div className="text-sm text-gray-500">
                {userData.creditScores?.length > 0 ? (
                  <span>Last updated {formatDate(userData.creditScores[0]?.date)}</span>
                ) : 'No update history'}
              </div>
            </div>
          ) : (
            <div className="text-center py-4 text-gray-400">No credit score available</div>
          )}
        </Card>

        {/* Lending Decision */}
        <Card title="Lending Decision" className="col-span-1">
          {decision ? (
            <div className="text-center">
              <div className={`text-2xl font-bold mb-2 ${decision.approved ? 'text-green-500' : 'text-red-500'}`}>
                {decision.approved ? 'Approved' : 'Not Approved'}
              </div>
              {decision.approved ? (
                <div className="space-y-2">
                  <div className="text-lg">Interest Rate: <span className="font-medium">{decision.interestRate}%</span></div>
                  <div className="text-lg">Max Amount: <span className="font-medium">${decision.maxAmount.toLocaleString()}</span></div>
                </div>
              ) : (
                <div className="text-gray-600">
                  <p>{decision.reason}</p>
                </div>
              )}
              <Button 
                type="primary" 
                className="mt-4" 
                onClick={makeLendingDecision}
                loading={decisionLoading}
              >
                Re-evaluate
              </Button>
            </div>
          ) : (
            <div className="text-center py-4">
              <Button 
                type="primary" 
                onClick={makeLendingDecision}
                loading={decisionLoading}
                size="large"
              >
                Make Lending Decision
              </Button>
            </div>
          )}
        </Card>
      </div>

      <Card title="Credit Score History" className="mt-6">
        <Table 
          dataSource={userData.creditScores?.map((record, index) => ({
            ...record,
            key: record.date || `record-${index}`,
            sortableDate: record.date ? new Date(record.date) : new Date(0)
          }))} 
          columns={columns}
          rowKey="key"
          loading={loading}
          pagination={{ pageSize: 5 }}
          className="shadow-sm"
          locale={{
            emptyText: 'No credit score history available'
          }}
        />
      </Card>

      {userData.factors?.length > 0 && (
        <Card title="Credit Factors" className="mt-6">
          <div className="space-y-4">
            {userData.factors.map((factor, index) => (
              <div key={index}>
                <div className="flex justify-between text-sm mb-1">
                  <span>{factor.name}</span>
                  <span className="font-medium">{factor.score}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="h-2 rounded-full"
                    style={{
                      width: `${Math.min(100, factor.score)}%`,
                      backgroundColor: factor.score >= 70 ? '#52c41a' : factor.score >= 40 ? '#faad14' : '#f5222d'
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};

export default LenderCreditDataViewer;
