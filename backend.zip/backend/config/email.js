import nodemailer from 'nodemailer';

// Log environment variables (without exposing sensitive data)
console.log('Email Configuration:', {
  host: 'sandbox.smtp.mailtrap.io',
  port: 2525,
  hasUser: !!process.env.SMTP_USER,
  hasPass: !!process.env.SMTP_PASS
});

const transporter = nodemailer.createTransport({
  host: 'sandbox.smtp.mailtrap.io',
  port: 2525,
  secure: false,
  auth: {
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || ''
  },
  tls: {
    ciphers: 'SSLv3'
  },
  debug: true,
  logger: true
});

// Verify connection configuration
transporter.verify(function (error, success) {
  if (error) {
    console.log('SMTP Error:', error);
    console.log('Current Environment Variables:', {
      SMTP_USER_EXISTS: !!process.env.SMTP_USER,
      SMTP_PASS_EXISTS: !!process.env.SMTP_PASS,
      SMTP_FROM_EXISTS: !!process.env.SMTP_FROM
    });
  } else {
    console.log('SMTP server is ready to take our messages');
  }
});

export const sendEmail = async ({ to, subject, html }) => {
  try {
    console.log('Attempting to send email with config:', {
      host: transporter.options.host,
      port: transporter.options.port,
      auth: {
        user: transporter.options.auth.user
      }
    });

    const info = await transporter.sendMail({
      from: process.env.SMTP_FROM || '"Credit Score Dashboard" <noreply@example.com>',
      to,
      subject,
      html,
    });
    console.log('Email sent:', info.messageId);
    return info;
  } catch (error) {
    console.error('Error sending email:', error);
    throw error;
  }
};

export const emailTemplates = {
  welcomeEmail: (username) => ({
    subject: 'Welcome to Credit Score Dashboard',
    html: `
      <h1>Welcome ${username}!</h1>
      <p>Thank you for joining Credit Score Dashboard. We're excited to help you monitor and improve your credit score.</p>
      <p>Get started by logging in to your dashboard.</p>
    `,
  }),
  
  passwordReset: (resetToken) => ({
    subject: 'Password Reset Request',
    html: `
      <h1>Password Reset Request</h1>
      <p>You requested to reset your password. Click the link below to proceed:</p>
      <a href="${process.env.FRONTEND_URL}/reset-password?token=${resetToken}">Reset Password</a>
      <p>If you didn't request this, please ignore this email.</p>
    `,
  }),

  scoreUpdate: (username, newScore) => ({
    subject: 'Credit Score Update',
    html: `
      <h1>Credit Score Update</h1>
      <p>Hello ${username},</p>
      <p>Your credit score has been updated to: ${newScore}</p>
      <p>Log in to your dashboard to see more details.</p>
    `,
  }),

  paymentSuccess: (username, plan, amount) => ({
    subject: 'Payment Successful - Credit Score Dashboard',
    html: `
      <h1>Payment Successful</h1>
      <p>Hello ${username},</p>
      <p>Your payment of ${amount} ETB for the ${plan} plan has been successfully processed.</p>
      <p>You now have access to all the features included in your plan.</p>
      <p>Thank you for choosing Credit Score Dashboard!</p>
    `,
  }),

  paymentFailed: (username, plan, amount) => ({
    subject: 'Payment Failed - Credit Score Dashboard',
    html: `
      <h1>Payment Failed</h1>
      <p>Hello ${username},</p>
      <p>We were unable to process your payment of ${amount} ETB for the ${plan} plan.</p>
      <p>Please try again or contact our support team if you need assistance.</p>
    `,
  }),

  subscriptionRenewal: (username, plan, amount, dueDate) => ({
    subject: 'Subscription Renewal Reminder - Credit Score Dashboard',
    html: `
      <h1>Subscription Renewal Reminder</h1>
      <p>Hello ${username},</p>
      <p>Your ${plan} plan subscription will be renewed on ${new Date(dueDate).toLocaleDateString()}.</p>
      <p>The renewal amount is ${amount} ETB.</p>
      <p>Please ensure you have sufficient funds in your account.</p>
    `,
  }),

  emailVerification: (username, token) => ({
    subject: 'Verify Your Email - Credit Score Dashboard',
    html: `
      <h1>Email Verification</h1>
      <p>Hello ${username},</p>
      <p>Thank you for registering with Credit Score Dashboard. Please verify your email address by clicking the link below:</p>
      <a href="${process.env.FRONTEND_URL}/verify-email?token=${token}">Verify Email</a>
      <p>This link will expire in 24 hours.</p>
      <p>If you didn't create an account, please ignore this email.</p>
    `,
  }),
};

export default { sendEmail, emailTemplates }; 