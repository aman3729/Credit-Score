import React, { useState, useEffect, useCallback } from 'react';
import api from '../utils/api';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import {
  LineChart,
  BarChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { FiAlertCircle, FiRefreshCw, FiCreditCard, FiUser, FiSearch } from 'react-icons/fi';
import { Tabs, Button, message, Input } from 'antd';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import DashboardLayout from './layout/DashboardLayout';
import LenderCreditDataViewer from './lender/LenderCreditDataViewer';

const COLORS = {
  primary: '#4F46E5',
  success: '#10B981',
  warning: '#F59E0B',
  danger: '#EF4444',
  background: 'var(--bg-color, #F9FAFB)',
  backgroundDark: '#1F2937',
  text: 'var(--text-color, #111827)',
  textDark: 'var(--text-dark, #F9FAFB)',
  border: 'var(--border-color, #E5E7EB)',
  borderDark: 'var(--border-dark, #374151)',
};

const ScoreIndicator = ({ score, max = 850, size = 120, strokeWidth = 12 }) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const progress = ((score - 300) / (max - 300)) * 100;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  const getScoreColor = (score) => {
    if (score >= 740) return COLORS.success;
    if (score >= 670) return '#3B82F6';
    if (score >= 580) return COLORS.warning;
    return COLORS.danger;
  };

  return (
    <div className="relative flex flex-col items-center">
      <svg width={size} height={size} className="transform -rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={COLORS.background}
          strokeWidth={strokeWidth}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={getScoreColor(score)}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 1s ease-in-out' }}
        />
      </svg>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
        <span className="text-3xl font-bold" style={{ color: getScoreColor(score) }}>
          {score}
        </span>
      </div>
    </div>
  );
};

const LenderDashboard = () => {
  console.log('Rendering LenderDashboard');
  
  // Debug: Log props and state
  const { user: currentUser, logout } = useAuth();
  const params = useParams();
  const navigate = useNavigate();
  
  useEffect(() => {
    console.log('LenderDashboard - User:', currentUser);
    console.log('LenderDashboard - User role:', currentUser?.role);
    console.log('LenderDashboard - URL params:', params);
  }, [currentUser, params]);
  
  // Handle logout
  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Failed to log out', error);
    }
  };
  
  const [searchInput, setSearchInput] = useState('');
  const [creditReport, setCreditReport] = useState(null);
  const [quickReport, setQuickReport] = useState(null);
  const [fraudCheck, setFraudCheck] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);
  
  // Updated activeTab state to default to 'credit'
  const [activeTab, setActiveTab] = useState('credit');
  
  const [borrowerData, setBorrowerData] = useState(null);
  const [loanHistory, setLoanHistory] = useState([]);
  const [riskLevel, setRiskLevel] = useState('medium');
  const [loanAmount, setLoanAmount] = useState(10000);
  const [loanTerm, setLoanTerm] = useState(12);
  const [interestRate, setInterestRate] = useState(5.5);
  const [aiEnabled, setAiEnabled] = useState(true);
  const [auditLogs, setAuditLogs] = useState([]);
  const [decisionResult, setDecisionResult] = useState(null);
  const [searchLoading, setSearchLoading] = useState(false);
  const [selectedBorrowerId, setSelectedBorrowerId] = useState(params.userId || currentUser?.id || '');
  
  // Use a ref to track if we've already fetched data
  const hasFetchedData = React.useRef(false);
  
  // Mock data for demonstration
  const mockBorrowerData = {
    name: 'John Doe',
    email: 'john.doe@example.com',
    phone: '(123) 456-7890',
    lastLogin: new Date().toISOString(),
    riskLevel: 'medium',
    loanHistory: [
      { id: 1, amount: 10000, status: 'Paid', date: '2023-01-15' },
      { id: 2, amount: 5000, status: 'Active', date: '2023-06-01' }
    ]
  };
  
  // Fetch borrower data
  const fetchBorrowerData = useCallback(async (userId) => {
    try {
      // For now, use mock data
      setBorrowerData(mockBorrowerData);
      setLoanHistory(mockBorrowerData.loanHistory);
      setRiskLevel(mockBorrowerData.riskLevel);
    } catch (error) {
      console.error('Error fetching borrower data:', error);
      // Fallback to mock data if API fails
      setBorrowerData(mockBorrowerData);
      setLoanHistory(mockBorrowerData.loanHistory);
      setRiskLevel(mockBorrowerData.riskLevel);
    }
  }, []);
  
  // Calculate monthly payment
  const calculateMonthlyPayment = useCallback(() => {
    if (!loanAmount || !loanTerm || !interestRate) return 0;
    const monthlyRate = (interestRate / 100) / 12;
    const payment = (loanAmount * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -loanTerm));
    return payment.toFixed(2);
  }, [loanAmount, loanTerm, interestRate]);
  
  // Fetch data when component mounts or selectedBorrowerId changes
  useEffect(() => {
    if (selectedBorrowerId && !hasFetchedData.current) {
      fetchBorrowerData(selectedBorrowerId);
      hasFetchedData.current = true;
    }
  }, [selectedBorrowerId, fetchBorrowerData]);

  // Update search input when selectedBorrowerId changes
  useEffect(() => {
    if (selectedBorrowerId) {
      setSearchInput(selectedBorrowerId);
    }
  }, [selectedBorrowerId]);

  // Redirect if no borrower is selected
  useEffect(() => {
    if (!selectedBorrowerId && currentUser?.id) {
      navigate(`/lender/${currentUser.id}`, { replace: true });
    } else if (!currentUser?.id) {
      navigate('/login', { replace: true });
    }
  }, [params.userId, currentUser?.id, navigate]);

  // Update selectedBorrowerId when URL params change
  useEffect(() => {
    setSelectedBorrowerId(params.userId || currentUser?.id || '');
  }, [params.userId, currentUser?.id]);

  // Fetch user data and credit report
  const fetchData = async () => {
    if (!userId) return;
    
    // Reset state for new data fetch
    setLoading(true);
    setError(null);
    
    try {
      // Get the token from localStorage
      const token = localStorage.getItem('token');
      if (!token) {
        navigate('/login');
        return;
      }
      
      // Only fetch data if we haven't already for this user
      if (!hasFetchedData.current) {
        hasFetchedData.current = true;
        
        try {
          // Fetch credit report
          const reportResponse = await api.get(`/api/credit-report/${userId}`);
          setCreditReport(reportResponse.data);
          
          // Fetch quick report if needed
          const quickReportResponse = await api.get(`/api/quick-report/${userId}`);
          setQuickReport(quickReportResponse.data);
          
          // Fetch fraud check if needed
          const fraudCheckResponse = await api.get(`/api/fraud-check/${userId}`);
          setFraudCheck(fraudCheckResponse.data);
        } catch (error) {
          console.error('Error fetching data:', error);
          if (error.response) {
            if (error.response.status === 401) {
              navigate('/login');
              return;
            } else if (error.response.status === 403) {
              setError('You do not have permission to view this user\'s data.');
            } else if (error.response.status === 404) {
              setError('User not found. Please check the user ID and try again.');
            } else {
              setError('Failed to load data. Please try again later.');
            }
          } else if (error.request) {
            setError('Unable to connect to the server. Please check your connection and try again.');
          } else {
            setError('An error occurred. Please try again.');
          }
        }
      }
    } catch (error) {
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };
  
  // Cleanup function to reset the ref if the component unmounts
  useEffect(() => {
    return () => {
      hasFetchedData.current = false;
    };
  }, [selectedBorrowerId, navigate]);

  const exportToPDF = async () => {
    const element = document.getElementById('report-container');
    const canvas = await html2canvas(element);
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`credit-report-${userId}.pdf`);
  };

  const fetchCreditData = async () => {
    try {
      setError(null);
      setRefreshing(true);
      
      // Mock data for testing
      const mockData = {
        score: 745,
        creditAccounts: [
          { accountName: 'Visa Card', balance: 12000, creditLimit: 30000 },
          { accountName: 'Auto Loan', balance: 8000, creditLimit: 20000 },
        ],
        riskFactors: [
          { factor: 'Credit Utilization', description: 'Using 33% of available credit', impact: 'low' },
          { factor: 'Recent Credit Inquiries', description: '3 hard inquiries in last 24 months', impact: 'low' },
          { factor: 'Credit History Length', description: 'Average account age is 5 years', impact: 'low' }
        ],
        scoreHistory: [
          { month: 'Jan', score: 710 },
          { month: 'Feb', score: 720 },
          { month: 'Mar', score: 735 },
          { month: 'Apr', score: 745 }
        ]
      };

      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Use mock data for now
      const reportData = mockData;

      // Set credit report with fallback data
      setCreditReport({
        score: reportData.score || 0,
        creditAccounts: reportData.creditAccounts || []
      });

      // Set quick report with risk factors
      setQuickReport({
        riskFactors: reportData.riskFactors || [],
        creditUtilization: 33,
        paymentHistory: { total: 24, onTime: 24, late30: 0, late60: 0, late90: 0 },
        accountSummary: { total: 5, open: 3, totalBalance: 20000, availableCredit: 50000, utilization: 28 }
      });

      // Set default fraud check data if not available
      if (!fraudCheck) {
        setFraudCheck({ 
          status: 'No fraud detected', 
          lastChecked: new Date().toISOString(),
          alerts: []
        });
      }
    } catch (error) {
      setError('Failed to load credit data. Please try again later.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        await fetchCreditData();
      } catch (err) {
        setError('Failed to load credit data. Please try again.');
        setLoading(false);
      }
    };
    loadData();
  }, [selectedBorrowerId]);

  const handleRefresh = () => {
    fetchCreditData();
  };

  // Handle borrower search with feedback
  const handleBorrowerSearch = () => {
    if (searchInput.trim()) {
      setSearchLoading(true);
      try {
        setSelectedBorrowerId(searchInput.trim());
        navigate(`/lender/${searchInput.trim()}`);
        message.success(`Loaded data for user: ${searchInput.trim()}`);
      } catch (error) {
        message.error('Failed to load user data');
      } finally {
        setSearchLoading(false);
      }
    } else {
      message.warning('Please enter a user ID');
    }
  };

  // Handle loan decision
  const handleLoanDecision = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // Mock response for demonstration
      const mockResponse = {
        approved: Math.random() > 0.3,
        reasons: [
          'Credit score meets minimum requirements',
          'Debt-to-income ratio is acceptable',
          'Sufficient credit history'
        ],
        suggestedTerms: {
          amount: loanAmount,
          term: loanTerm,
          interestRate: interestRate + (Math.random() * 2 - 1),
          monthlyPayment: calculateMonthlyPayment()
        }
      };
      
      // Show the result
      setDecisionResult(mockResponse);
      
      // Add to audit log
      setAuditLogs(prev => [{
        action: 'Loan Decision',
        details: `Decision: ${mockResponse.approved ? 'Approved' : 'Denied'}, Amount: $${loanAmount}`,
        timestamp: new Date().toISOString(),
        performedBy: currentUser?.id || 'system'
      }, ...prev]);
      
    } catch (error) {
      setError('Failed to process loan decision');
    } finally {
      setLoading(false);
    }
  };
  
  // Borrower Profile Component
  const BorrowerProfile = () => (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <h2 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Borrower Profile</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-3">Personal Information</h3>
          <div className="space-y-2">
            <p><span className="font-medium text-gray-600 dark:text-gray-400">Name:</span> {borrowerData?.name || 'N/A'}</p>
            <p><span className="font-medium text-gray-600 dark:text-gray-400">Email:</span> {borrowerData?.email || 'N/A'}</p>
            <p><span className="font-medium text-gray-600 dark:text-gray-400">Phone:</span> {borrowerData?.phone || 'N/A'}</p>
            <p><span className="font-medium text-gray-600 dark:text-gray-400">Last Login:</span> {borrowerData?.lastLogin ? format(new Date(borrowerData.lastLogin), 'MMM d, yyyy hh:mm a') : 'N/A'}</p>
          </div>
        </div>
        <div>
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-3">Risk Assessment</h3>
          <div className="flex items-center mb-4">
            <span className="font-medium text-gray-600 dark:text-gray-400 mr-2">Risk Level:</span>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
              riskLevel === 'low' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
              riskLevel === 'medium' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' :
              'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
            }`}>
              {riskLevel ? riskLevel.charAt(0).toUpperCase() + riskLevel.slice(1) : 'N/A'}
            </span>
          </div>
          
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-3">Loan History</h3>
          {loanHistory?.length > 0 ? (
            <div className="space-y-2">
              {loanHistory.map(loan => (
                <div key={loan.id} className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                  <div>
                    <p className="font-medium">${loan.amount.toLocaleString()}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{loan.date}</p>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    loan.status === 'Paid' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
                    'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                  }`}>
                    {loan.status}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 dark:text-gray-400">No loan history available</p>
          )}
        </div>
      </div>
    </div>
  );

  // Audit Logs Component
  const AuditLogs = () => (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 mt-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Audit Logs</h2>
        <button
          onClick={() => {
            setAuditLogs(prev => [{
              action: 'Page Refresh',
              details: 'Audit logs refreshed',
              timestamp: new Date().toISOString(),
              performedBy: currentUser?.id || 'system'
            }, ...prev]);
          }}
          className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          Refresh Logs
        </button>
      </div>
      
      <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 rounded-lg">
        <table className="min-w-full divide-y divide-gray-300 dark:divide-gray-600">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 dark:text-gray-100 sm:pl-6">
                Timestamp
              </th>
              <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900 dark:text-gray-100">
                Action
              </th>
              <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900 dark:text-gray-100">
                Details
              </th>
              <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900 dark:text-gray-100">
                User
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-gray-700 bg-white dark:bg-gray-800">
            {auditLogs.length > 0 ? (
              auditLogs.map((log, idx) => (
                <tr key={idx} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm text-gray-900 dark:text-gray-100 sm:pl-6">
                    {format(new Date(log.timestamp), 'MMM d, yyyy HH:mm:ss')}
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-700 dark:text-gray-300">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                      {log.action}
                    </span>
                  </td>
                  <td className="px-3 py-4 text-sm text-gray-700 dark:text-gray-300">
                    {log.details}
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-700 dark:text-gray-300">
                    {log.performedBy}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4" className="px-3 py-4 text-sm text-center text-gray-500 dark:text-gray-400">
                  No audit logs available
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  // Loan Decision Engine Component
  const LoanDecisionEngine = () => (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 mt-6">
      <h2 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Loan Decision Engine</h2>
      <form onSubmit={handleLoanDecision} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Loan Amount ($)
            </label>
            <input
              type="number"
              value={loanAmount}
              onChange={(e) => setLoanAmount(Number(e.target.value))}
              className="w-full p-2 border rounded-md dark:bg-gray-700 dark:border-gray-600"
              min="100"
              step="100"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Term (months)
            </label>
            <select
              value={loanTerm}
              onChange={(e) => setLoanTerm(Number(e.target.value))}
              className="w-full p-2 border rounded-md dark:bg-gray-700 dark:border-gray-600"
              required
            >
              <option value="12">12 months</option>
              <option value="24">24 months</option>
              <option value="36">36 months</option>
              <option value="60">60 months</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Interest Rate (%)
            </label>
            <input
              type="number"
              value={interestRate}
              onChange={(e) => setInterestRate(Number(e.target.value))}
              className="w-full p-2 border rounded-md dark:bg-gray-700 dark:border-gray-600"
              min="1"
              max="30"
              step="0.1"
              required
            />
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <input
              id="ai-enabled"
              type="checkbox"
              checked={aiEnabled}
              onChange={(e) => setAiEnabled(e.target.checked)}
              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
            />
            <label htmlFor="ai-enabled" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
              Enable AI Scoring
            </label>
          </div>
          
          <div className="text-right">
            <p className="text-sm text-gray-600 dark:text-gray-300">
              Estimated Payment: <span className="font-semibold">${calculateMonthlyPayment()}/mo</span>
            </p>
          </div>
        </div>
        
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={loading}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
              </>
            ) : 'Get Decision'}
          </button>
        </div>
      </form>
      
      {decisionResult && (
        <div className={`mt-6 p-4 rounded-md ${
          decisionResult.approved ? 'bg-green-50 dark:bg-green-900/30' : 'bg-red-50 dark:bg-red-900/30'
        }`}>
          <h3 className={`text-lg font-medium ${
            decisionResult.approved ? 'text-green-800 dark:text-green-200' : 'text-red-800 dark:text-red-200'
          }`}>
            {decisionResult.approved ? '✓ Approved' : '✗ Not Approved'}
          </h3>
          <div className="mt-2 text-sm">
            {decisionResult.reasons?.map((reason, i) => (
              <p key={i} className="mt-1">• {reason}</p>
            ))}
            {decisionResult.suggestedTerms && (
              <div className="mt-2">
                <p className="font-medium">Suggested Terms:</p>
                <pre className="text-xs bg-black/10 dark:bg-white/10 p-2 rounded mt-1 overflow-auto">
                  {JSON.stringify(decisionResult.suggestedTerms, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );

  if (loading && !refreshing) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
        <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-500 dark:border-blue-400 border-t-transparent"></div>
        <p className="mt-4 text-gray-600 dark:text-gray-400">Loading credit report...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="bg-red-50 dark:bg-red-900/20 border-l-4 border-red-500 dark:border-red-600 p-4 rounded-lg">
          <div className="flex items-center">
            <FiAlertCircle className="h-5 w-5 text-red-500 dark:text-red-400 mr-3" />
            <div>
              <p className="text-sm text-red-700 dark:text-red-400">
                {error} <button 
                  onClick={handleRefresh}
                  className="underline text-red-700 dark:text-red-400 hover:text-red-800 dark:hover:text-red-500 font-medium"
                >
                  Try again
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <DashboardLayout 
      userName={currentUser?.name || 'Lender'}
      onLogout={handleLogout}
      center={
        <div id="report-container" className="space-y-6">
          {/* User Info Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Credit Analysis</h1>
              <div className="flex items-center gap-2">
                <p className="text-gray-600 dark:text-gray-400">User ID: {selectedBorrowerId}</p>
                {creditReport?.score && creditReport.score < 600 && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-400">
                    High Risk
                  </span>
                )}
                {fraudCheck?.status !== 'No fraud detected' && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-400">
                    Fraud Alert
                  </span>
                )}
              </div>
            </div>
            <div className="mt-4 md:mt-0">
              <button
                onClick={exportToPDF}
                className="flex items-center px-4 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                Export PDF
              </button>
            </div>
          </div>

          {/* Consolidated Tabs Section */}
          <div className="bg-white rounded-lg shadow">
            <Tabs
              activeKey={activeTab}
              onChange={setActiveTab}
              items={[
                {
                  key: 'credit',
                  label: (
                    <span className="flex items-center">
                      <FiCreditCard className="mr-2" />
                      Credit Data
                    </span>
                  ),
                  children: (
                    <div className="p-4">
                      <LenderCreditDataViewer 
                        creditData={creditReport} 
                        borrowerId={selectedBorrowerId}
                      />
                    </div>
                  )
                },
                {
                  key: 'borrower',
                  label: (
                    <span className="flex items-center">
                      <FiUser className="mr-2" />
                      Borrower
                    </span>
                  ),
                  children: (
                    <div className="p-4">
                      <BorrowerProfile borrowerId={selectedBorrowerId} />
                    </div>
                  )
                }
              ]}
              tabBarExtraContent={
                <div className="flex items-center gap-4">
                  <Input
                    prefix={<FiSearch className="text-gray-400" />}
                    value={searchInput}
                    onChange={(e) => setSearchInput(e.target.value)}
                    onPressEnter={handleBorrowerSearch}
                    placeholder="Search borrower ID"
                    className="w-64"
                  />
                  <Button onClick={handleBorrowerSearch} loading={searchLoading}>
                    {searchLoading ? 'Searching...' : 'Search'}
                  </Button>
                </div>
              }
            />
          </div>
        </div>
      }
    />
  );
};

export default LenderDashboard;