import React, { useState } from 'react';
import { Button, Card, Progress, Alert, Switch, Space, Typography, Upload, message } from 'antd';
import { UploadOutlined, FileDoneOutlined, CloseCircleOutlined, DownloadOutlined } from '@ant-design/icons';
import api from '../utils/api';

const { Title, Text } = Typography;

const AdminBatchUpload = ({ onClose, onUploadComplete }) => {
  const [file, setFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [useAI, setUseAI] = useState(false);
  const [results, setResults] = useState(null);

  const beforeUpload = (file) => {
    const isJSON = file.type === 'application/json';
    const isCSV = file.type === 'text/csv' || file.name.endsWith('.csv');
    
    if (!isJSON && !isCSV) {
      message.error('You can only upload JSON or CSV files!');
      return Upload.LIST_IGNORE;
    }
    
    setFile(file);
    setResults(null);
    return false; // Prevent auto upload
  };

  const handleUpload = async () => {
    if (!file) {
      message.warning('Please select a file first');
      return;
    }

    const formData = new FormData();
    
    try {
      // Read the file as text first to validate it's valid JSON
      const fileContent = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.onerror = (error) => reject(error);
        reader.readAsText(file);
      });
      
      // Try to parse the JSON to validate it
      try {
        const parsed = JSON.parse(fileContent);
        // If we get here, the JSON is valid
        console.log('File contains valid JSON');
      } catch (parseError) {
        console.error('Invalid JSON in file:', parseError);
        message.error('The file contains invalid JSON. Please check the file and try again.');
        return;
      }
      
      // Add the original file to form data
      formData.append('file', file);
      
      // Log file info for debugging
      console.log('File prepared for upload:', {
        name: file.name,
        type: file.type,
        size: file.size,
        lastModified: new Date(file.lastModified).toISOString()
      });
      
      setIsUploading(true);
      setProgress(0);
      
      // Simulate progress
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 10;
        });
      }, 300);
      
      console.log('Sending batch upload request with AI enabled:', useAI);
      
      const response = await api.post('/api/upload/batch', formData, {
        params: { aiEnabled: useAI },
        headers: {
          'Content-Type': 'multipart/form-data',
          'Accept': 'application/json'
        },
        onUploadProgress: (progressEvent) => {
          if (progressEvent.lengthComputable) {
            const percentCompleted = Math.round(
              (progressEvent.loaded * 100) / progressEvent.total
            );
            setProgress(Math.min(percentCompleted, 90));
          }
        },
      });
      
      console.log('Batch upload response:', response);
      
      clearInterval(progressInterval);
      setProgress(100);
      
      setResults({
        total: response.data.total,
        success: response.data.success,
        errors: response.data.errors,
        results: response.data.results,
      });
      
      message.success(`Successfully processed ${response.data.success} records`);
      
      if (onUploadComplete) {
        onUploadComplete(response.data);
      }
    } catch (error) {
      console.error('Upload failed:', error);
      let errorMessage = 'Upload failed. Please try again.';
      
      if (error.response) {
        // Server responded with an error
        errorMessage = error.response.data?.message || 
                     error.response.data?.error || 
                     'Server error occurred during upload.';
      } else if (error.request) {
        // Request was made but no response received
        errorMessage = 'No response from server. Please check your connection.';
      } else if (error.message) {
        // Error occurred in setting up the request
        errorMessage = `Upload error: ${error.message}`;
      }
      
      message.error(errorMessage);
      setProgress(0);
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemove = () => {
    setFile(null);
    setResults(null);
    setProgress(0);
  };

  return (
    <Card 
      title={
        <Space>
          <FileDoneOutlined />
          <span>Batch Upload Credit Data</span>
        </Space>
      }
      style={{ marginBottom: 24 }}
      extra={onClose && <Button type="text" icon={<CloseCircleOutlined />} onClick={onClose} />}
    >
      <div style={{ marginBottom: 16 }}>
        <Upload.Dragger 
          beforeUpload={beforeUpload}
          fileList={file ? [file] : []}
          showUploadList={{
            showRemoveIcon: true,
            removeIcon: <CloseCircleOutlined onClick={handleRemove} />,
          }}
          accept=".json,.csv"
          maxCount={1}
        >
          <p className="ant-upload-drag-icon">
            <UploadOutlined />
          </p>
          <p className="ant-upload-text">
            Click or drag file to this area to upload
          </p>
          <p className="ant-upload-hint">
            Support for a single JSON or CSV file
          </p>
        </Upload.Dragger>
      </div>
      
      <div style={{ margin: '16px 0' }}>
        <Space>
          <Switch 
            checked={useAI} 
            onChange={setUseAI} 
            checkedChildren="AI Scoring" 
            unCheckedChildren="Manual Scoring" 
          />
          <Text type="secondary">
            {useAI 
              ? 'Using AI-powered credit scoring' 
              : 'Using traditional scoring model'}
          </Text>
        </Space>
      </div>
      
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <Button
          type="primary"
          onClick={handleUpload}
          disabled={!file || isUploading}
          loading={isUploading}
          icon={<UploadOutlined />}
        >
          {isUploading ? 'Processing...' : 'Start Batch Processing'}
        </Button>
        
        <Button
          type="default"
          icon={<DownloadOutlined />}
          onClick={() => {
            // Implement download template functionality
            const template = [{
              email: 'user@example.com',
              paymentHistory: 0.95,
              creditUtilization: 0.3,
              creditAge: 5,
              creditMix: 0.8,
              inquiries: 2
            }];
            
            const blob = new Blob([JSON.stringify(template, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'credit_data_template.json';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
          }}
        >
          Download Template
        </Button>
      </div>
      
      {progress > 0 && (
        <div style={{ marginBottom: 16 }}>
          <Progress 
            percent={progress} 
            status={progress < 100 ? 'active' : 'success'}
            size="small"
            strokeWidth={4}
            showInfo={false}
          />
        </div>
      )}
      
      {results && (
        <div style={{ marginTop: 16 }}>
          <Alert
            message={`Processed ${results.total} records`}
            description={
              <div>
                <p>✅ {results.success} successful</p>
                {results.errors > 0 && (
                  <p>❌ {results.errors} failed</p>
                )}
                {results.results && results.results.some(r => r.status === 'failed') && (
                  <div style={{ marginTop: 8 }}>
                    <p>Failed records:</p>
                    <ul style={{ marginLeft: 16 }}>
                      {results.results
                        .filter(r => r.status === 'failed')
                        .map((r, i) => (
                          <li key={i}>
                            {r.email || 'Unknown'}: {r.message}
                          </li>
                        ))}
                    </ul>
                  </div>
                )}
              </div>
            }
            type={results.errors === 0 ? 'success' : 'warning'}
            showIcon
          />
        </div>
      )}
    </Card>
  );
};

export default AdminBatchUpload;