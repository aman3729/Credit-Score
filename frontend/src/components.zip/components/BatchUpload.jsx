import React, { useState, useCallback } from 'react';
import { Upload, Button, message, Card, Progress, Alert, Switch, Space, Typography } from 'antd';
import { UploadOutlined, FileDoneOutlined, CloseCircleOutlined } from '@ant-design/icons';
import api from '../utils/api';

const { Title, Text } = Typography;

const BatchUpload = ({ onUploadComplete }) => {
  const [file, setFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [useAI, setUseAI] = useState(false);
  const [results, setResults] = useState(null);

  const beforeUpload = (file) => {
    const isJSON = file.type === 'application/json';
    const isCSV = file.type === 'text/csv' || file.name.endsWith('.csv');
    
    if (!isJSON && !isCSV) {
      message.error('You can only upload JSON or CSV files!');
      return Upload.LIST_IGNORE;
    }
    
    setFile(file);
    setResults(null);
    return false; // Prevent auto upload
  };

  const handleUpload = async () => {
    if (!file) {
      message.warning('Please select a file first');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);
    
    setIsUploading(true);
    setProgress(0);
    
    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 10;
        });
      }, 300);
      
      const response = await api.post('/api/upload/batch', formData, {
        params: { aiEnabled: useAI },
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          );
          setProgress(Math.min(percentCompleted, 90)); // Cap at 90% until complete
        },
      });
      
      clearInterval(progressInterval);
      setProgress(100);
      
      setResults({
        total: response.data.total,
        success: response.data.success,
        errors: response.data.errors,
        results: response.data.results,
      });
      
      message.success(`Successfully processed ${response.data.success} records`);
      
      if (onUploadComplete) {
        onUploadComplete(response.data);
      }
    } catch (error) {
      console.error('Upload failed:', error);
      message.error(
        error.response?.data?.message || 'Upload failed. Please try again.'
      );
      setProgress(0);
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemove = () => {
    setFile(null);
    setResults(null);
    setProgress(0);
  };

  const uploadProps = {
    beforeUpload,
    fileList: file ? [file] : [],
    showUploadList: {
      showRemoveIcon: true,
      removeIcon: <CloseCircleOutlined onClick={handleRemove} />,
    },
    accept: '.json,.csv',
    maxCount: 1,
  };

  return (
    <Card 
      title={
        <Space>
          <FileDoneOutlined />
          <span>Batch Upload Credit Data</span>
        </Space>
      }
      style={{ marginBottom: 24 }}
    >
      <div style={{ marginBottom: 16 }}>
        <Upload.Dragger {...uploadProps}>
          <p className="ant-upload-drag-icon">
            <UploadOutlined />
          </p>
          <p className="ant-upload-text">
            Click or drag file to this area to upload
          </p>
          <p className="ant-upload-hint">
            Support for a single JSON or CSV file
          </p>
        </Upload.Dragger>
      </div>
      
      <div style={{ margin: '16px 0' }}>
        <Space>
          <Switch 
            checked={useAI} 
            onChange={setUseAI} 
            checkedChildren="AI Scoring" 
            unCheckedChildren="Manual Scoring" 
          />
          <Text type="secondary">
            {useAI 
              ? 'Using AI-powered credit scoring' 
              : 'Using traditional scoring model'}
          </Text>
        </Space>
      </div>
      
      <Button
        type="primary"
        onClick={handleUpload}
        disabled={!file || isUploading}
        loading={isUploading}
        style={{ marginTop: 8 }}
      >
        {isUploading ? 'Processing...' : 'Start Batch Processing'}
      </Button>
      
      {progress > 0 && (
        <div style={{ marginTop: 16 }}>
          <Progress 
            percent={progress} 
            status={progress < 100 ? 'active' : 'success'}
            strokeWidth={4}
          />
        </div>
      )}
      
      {results && (
        <div style={{ marginTop: 16 }}>
          <Alert
            message={`Processed ${results.total} records`}
            description={
              <div>
                <p>✅ {results.success} successful</p>
                {results.errors > 0 && (
                  <p>❌ {results.errors} failed</p>
                )}
              </div>
            }
            type={results.errors === 0 ? 'success' : 'warning'}
            showIcon
          />
        </div>
      )}
    </Card>
  );
};

export default BatchUpload;
