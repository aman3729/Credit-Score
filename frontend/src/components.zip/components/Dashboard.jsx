import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../utils/api';

// Import components
import DashboardLayout from './layout/DashboardLayout';
import CreditScoreDisplay from './CreditScoreDisplay';
import CreditFactorCard from './CreditFactorCard';
import ScoreHistoryChart from './ScoreHistoryChart';
import RecentActivity from './RecentActivity';
import CreditHealthSummary from './CreditHealthSummary';

// Import new modular components
import Card from './Dashboard/Card';
import PricingPlan from './Dashboard/PricingPlan';
import QuickActions from './Dashboard/QuickActions';
import Recommendations from './Dashboard/Recommendations';

// Mock data for the dashboard
const mockScoreHistory = [
  { month: 'Jan', score: 650 },
  { month: 'Feb', score: 665 },
  { month: 'Mar', score: 680 },
  { month: 'Apr', score: 690 },
  { month: 'May', score: 710 },
  { month: 'Jun', score: 720 },
  { month: 'Jul', score: 730 },
  { month: 'Aug', score: 735 },
  { month: 'Sep', score: 740 },
  { month: 'Oct', score: 745 },
  { month: 'Nov', score: 750 },
  { month: 'Dec', score: 755 },
];

const recentActivity = [
  { id: 1, action: 'Credit score updated', date: '2 hours ago', change: '+5' },
  { id: 2, action: 'Viewed credit report', date: '1 day ago' },
  { id: 3, action: 'New credit inquiry', date: '3 days ago', change: '-2' },
];

const Dashboard = ({ onLogout }) => {
  const { user } = useAuth();
  console.log('[Dashboard] Rendering with user:', user);
  const safeUser = {
    username: '',
    email: '',
    name: '',
    ...user
  };

  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState(null);
  const [creditData, setCreditData] = useState({
    score: 0,
    factors: [],
    history: []
  });
  
  // Ensure factors is always an array with safe defaults
  const safeFactors = Array.isArray(creditData?.factors) 
    ? creditData.factors 
    : [];

  const defaultFactors = [
    { name: 'Payment History', score: 35, status: 'good' },
    { name: 'Credit Utilization', score: 30, status: 'good' },
    { name: 'Credit History Length', score: 15, status: 'fair' },
    { name: 'Credit Mix', score: 10, status: 'fair' },
    { name: 'New Credit', score: 10, status: 'good' }
  ];

  const scoreRanges = [
    { range: '300-579', color: 'bg-red-500' },
    { range: '580-669', color: 'bg-orange-500' },
    { range: '670-739', color: 'bg-yellow-500' },
    { range: '740-799', color: 'bg-green-500' },
    { range: '800-850', color: 'bg-green-600' }
  ];

  const fetchCreditData = async () => {
    console.log('[Dashboard] fetchCreditData called');
    const userId = user?._id || user?.id;

    if (!userId) {
      const errorMsg = 'User not authenticated - no user ID available';
      console.error('[Dashboard]', errorMsg);
      setError(errorMsg);
      setIsLoading(false);
      return;
    }

    // Set a timeout to prevent infinite loading
    const timeoutId = setTimeout(() => {
      if (isMounted.current) {
        console.error('[Dashboard] Request timeout');
        setError('Request timed out. Please try again.');
        setIsLoading(false);
        setIsRefreshing(false);
      }
    }, 10000); // 10 second timeout

    try {
      const userId = user?._id || user?.id;
      if (!userId) {
        console.error('[Dashboard] No user ID available');
        throw new Error('No user ID available');
      }

      console.log(`[Dashboard] Fetching credit score for user ${userId} at ${new Date().toISOString()}`);

      // Use the API utility which has the baseURL and credentials configured
      console.log('[Dashboard] Fetching credit score for user:', userId);

      const response = await api.get(`/api/credit-score/${userId}`, {
        headers: {
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache',
          'X-Request-ID': Date.now().toString()
        },
        timeout: 10000, // 10 second timeout
        withCredentials: true
      });

      console.log('[Dashboard] Request successful, status:', response.status);

      // Don't log sensitive response data in production
      if (process.env.NODE_ENV !== 'production') {
        console.log('[Dashboard] Response data:', response.data);
      }

      // Only update state if component is still mounted
      if (!isMounted.current) {
        console.log('[Dashboard] Component unmounted, skipping state update');
        return;
      }

      // Process the response data
      const responseData = response.data;
      if (!responseData) {
        throw new Error('No data received from server');
      }

      // Update the credit data state
      const newCreditData = {
        score: responseData.score || 700,
        factors: responseData.factors || defaultFactors,
        history: responseData.history || [{
          date: new Date().toISOString(),
          score: responseData.score || 700,
          change: 0
        }]
      };

      console.log('[Dashboard] Updating credit data:', newCreditData);
      setCreditData(newCreditData);
      setError(null);
    } catch (error) {
      console.error('Error fetching credit score:', {
        name: error.name,
        message: error.message,
        status: error.response?.status,
        statusText: error.response?.statusText,
        responseData: error.response?.data,
        config: {
          url: error.config?.url,
          method: error.config?.method,
          headers: error.config?.headers,
          withCredentials: error.config?.withCredentials,
          timeout: error.config?.timeout
        },
        code: error.code,
        stack: error.stack
      });

      // Only update state if component is still mounted
      if (!isMounted.current) return;

      if (error.response?.status === 404) {
        console.log('[DEBUG] No credit score found, using default data');
        setCreditData({
          score: 700,
          factors: defaultFactors,
          history: [{ date: new Date().toISOString(), score: 700, change: 0 }]
        });
      } else if (error.response?.status === 401 || error.response?.status === 403) {
        console.error('[ERROR] Authentication error, redirecting to login');
        window.location.href = '/login';
      } else {
        const errorMessage = error.response?.data?.error || 'Failed to load credit data. Please try again.';
        console.error(`[ERROR] ${errorMessage}`);
        setError(errorMessage);
      }
    } finally {
      clearTimeout(timeoutId);
      if (isMounted.current) {
        setIsLoading(false);
        setIsRefreshing(false);
      }
    }
  };
  
  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchCreditData();
  };
  
  // Track mounted state
  const isMounted = useRef(true);

  // Set up the effect for fetching data
  useEffect(() => {
    // Reset mounted state when component mounts
    isMounted.current = true;
    
    const userId = user?._id || user?.id;
    console.log('[Dashboard] useEffect running', { 
      userId,
      isLoading, 
      isRefreshing,
      hasUser: !!user,
      userKeys: user ? Object.keys(user) : 'no user'
    });
    
    // Only fetch if we have a user ID
    if (userId) {
      console.log('[Dashboard] Fetching data for user:', userId);
      fetchCreditData();
    } else {
      console.log('[Dashboard] No user ID available, not fetching data');
      setIsLoading(false);
    }

    // Cleanup function
    return () => {
      console.log('[Dashboard] Cleaning up');
      isMounted.current = false;
    };
  }, [user?._id, user?.id]); // Only depend on user ID changes

  const handleScoreUpdate = async (newScore) => {
    const userId = user?._id || user?.id;
    if (!userId) return;

    try {
      console.log(`[DEBUG] Updating score for user ${userId} to ${newScore}`);
      await api.put(`/api/credit-score/${userId}`, { score: newScore });
      setCreditData(prev => ({ ...prev, score: newScore }));
    } catch (error) {
      const errorDetails = {
        message: error.message,
        response: error.response?.data,
        status: error.response?.status,
        stack: error.stack
      };
      console.error('[Dashboard] Error updating score:', errorDetails);

      if (isMounted.current) {
        const errorMessage = error.response?.data?.message || 'Failed to update score';
        console.error('[Dashboard] Setting error state:', errorMessage);
        setError(errorMessage);
      }
    }
  };

  if (isLoading) {
    console.log('[Dashboard] Rendering loading state');
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin h-12 w-12 border-b-2 border-blue-500 rounded-full mx-auto"></div>
          <p className="text-gray-600 dark:text-gray-300 text-lg">Loading your dashboard...</p>
          <p className="text-sm text-gray-500">User ID: {user?._id || user?.id || 'No user ID'}</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4">
        <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl max-w-md w-full text-center space-y-4 border border-gray-200 dark:border-gray-700">
          <div className="text-red-500 text-5xl">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <h2 className="text-2xl font-semibold text-gray-800 dark:text-white">Error Loading Dashboard</h2>
          <p className="text-gray-600 dark:text-gray-300">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-colors duration-200 w-full sm:w-auto"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  // Calculate score change for the last 12 months
  const currentScore = creditData.score;
  const previousScore = creditData.history[0]?.score || 0;
  const scoreChange = currentScore - previousScore;
  const formattedScoreChange = scoreChange >= 0 ? `+${scoreChange}` : scoreChange.toString();



  return (
    <DashboardLayout
      left={
        <div className="lg:sticky lg:top-4">
          <CreditHealthSummary 
            score={currentScore} 
            factors={creditData.factors} 
          />
        </div>
      }
      center={
        <div className="space-y-8">
          <Card>
            <CreditScoreDisplay 
              score={currentScore} 
              change={scoreChange}
              lastUpdated={creditData.history[0]?.date || new Date().toISOString()}
              onRefresh={handleRefresh}
              loading={isRefreshing}
            />
          </Card>
          
          <Card className="space-y-6 border border-gray-100 dark:border-gray-700">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Credit Factors</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2 gap-4">
              {safeFactors.map((factor, index) => (
                <CreditFactorCard 
                  key={factor?._id || index} 
                  name={factor.name}
                  score={factor.score}
                  status={factor.status}
                  description={factor.description}
                  icon={factor.icon || <FiCreditCard className="text-indigo-500" />}
                />
              ))}
            </div>
          </Card>

          <Card>
            <ScoreHistoryChart data={mockScoreHistory} />
          </Card>
          
          <Card className="transition-colors duration-200">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2 text-center">Choose Your Plan</h2>
            <p className="text-gray-600 dark:text-gray-300 text-center mb-8">Select the plan that best fits your needs</p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <PricingPlan
                name="Basic"
                price="9.99"
                features={[
                  { text: 'Credit Score', included: true },
                  { text: 'Credit Report', included: true },
                  { text: 'Identity Theft Protection', included: false },
                ]}
              />
              
              <PricingPlan
                name="Premium"
                price="19.99"
                popular
                className="relative"
                features={[
                  { text: 'Everything in Basic', included: true },
                  { text: 'Identity Theft Protection', included: true },
                  { text: '24/7 Credit Monitoring', included: true },
                ]}
              />
              
              <PricingPlan
                name="Enterprise"
                price="49.99"
                features={[
                  { text: 'Everything in Premium', included: true },
                  { text: 'Dedicated Account Manager', included: true },
                  { text: 'API Access', included: true },
                ]}
              />
            </div>
            
            <div className="mt-8 pt-6 border-t border-gray-100 dark:border-gray-700">
              <p className="text-center text-sm text-gray-500 dark:text-gray-400">
                All plans come with a 14-day money-back guarantee. No credit card required to start.
              </p>
            </div>
          </Card>
        </div>
      }
      right={
        <div className="space-y-6">
          <Card>
            <QuickActions />
          </Card>
          
          <Card>
            <Recommendations />
          </Card>
          
          <Card>
            <RecentActivity activities={recentActivity} />
          </Card>
        </div>
      }
      userName={safeUser.name || 'User'}
      onLogout={onLogout}
    />
  );
};

export default Dashboard;
