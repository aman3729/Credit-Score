import React, { useState } from 'react';
import { Card, Table, Button, Input, message, Badge, Tag, Descriptions } from 'antd';
import { UserOutlined, SearchOutlined, ArrowLeftOutlined } from '@ant-design/icons';
import { api } from '../../lib/api';

const UserDataViewer = () => {
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [userId, setUserId] = useState('');

  const fetchUserData = async () => {
    if (!userId) {
      message.warning('Please enter a user ID');
      return;
    }

    try {
      setLoading(true);
      const response = await api.get(`/users/${userId}/credit-data`);
      
      // Log the response to help with debugging
      console.log('API Response:', response.data);
      
      // Transform the data to match our expected format
      const transformedData = {
        user: response.data.data.user,
        currentScore: response.data.data.creditScores?.[0]?.score,
        creditScores: response.data.data.creditScores || [],
        factors: response.data.data.factors || []
      };
      
      console.log('Transformed Data:', transformedData);
      setUserData(transformedData);
      message.success('User data loaded successfully');
    } catch (error) {
      console.error('Error fetching user data:', error);
      message.error(error.response?.data?.error || 'Failed to fetch user data');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    try {
      if (!dateString) return 'N/A';
      const date = new Date(dateString);
      return isNaN(date) ? 'Invalid Date' : date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (error) {
      console.error('Error formatting date:', error);
      return 'Invalid Date';
    }
  };

  const columns = [
    {
      title: 'Date',
      dataIndex: 'date',
      key: 'date',
      render: (date) => formatDate(date),
      sorter: (a, b) => new Date(a.date || 0) - new Date(b.date || 0),
      defaultSortOrder: 'descend',
      width: 200,
    },
    {
      title: 'Score',
      dataIndex: 'score',
      key: 'score',
      render: (score) => {
        if (score === undefined || score === null) return 'N/A';
        const displayScore = Math.min(Math.round(score), 999); // Cap at 999
        const color = score >= 700 ? '#52c41a' : score >= 600 ? '#faad14' : '#f5222d';
        
        return (
          <div className="flex items-center">
            <div 
              style={{
                backgroundColor: color,
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontWeight: 'bold',
                marginRight: '8px'
              }}
            >
              {displayScore}
            </div>
            <div>
              <div className="font-medium">{displayScore}</div>
              <div className="text-xs text-gray-500">
                {score >= 700 ? 'Excellent' : score >= 600 ? 'Good' : 'Needs Improvement'}
              </div>
            </div>
          </div>
        );
      },
      sorter: (a, b) => (a.score || 0) - (b.score || 0),
      width: 200,
    },
    {
      title: 'Change',
      key: 'change',
      render: (_, record) => {
        if (record.change === undefined || record.change === null) return 'N/A';
        const isPositive = record.change >= 0;
        const changeText = isPositive ? `+${record.change}` : record.change;
        
        return (
          <span className={`inline-flex items-center ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
            {isPositive ? (
              <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
              </svg>
            ) : (
              <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            )}
            {changeText} pts
          </span>
        );
      },
      width: 150,
    },
    {
      title: 'Status',
      key: 'status',
      render: (_, record) => {
        const score = record.score || 0;
        let status, color;
        
        if (score >= 700) {
          status = 'Excellent';
          color = 'success';
        } else if (score >= 600) {
          status = 'Good';
          color = 'warning';
        } else {
          status = 'Needs Improvement';
          color = 'error';
        }
        
        return <Tag color={color} className="capitalize">{status}</Tag>;
      },
      filters: [
        { text: 'Excellent (700+)', value: 'excellent' },
        { text: 'Good (600-699)', value: 'good' },
        { text: 'Needs Improvement (<600)', value: 'needs_improvement' },
      ],
      onFilter: (value, record) => {
        const score = record.score || 0;
        if (value === 'excellent') return score >= 700;
        if (value === 'good') return score >= 600 && score < 700;
        return score < 600;
      },
      width: 180,
    },
  ];

  if (userData) {
    return (
      <Card 
        title={
          <div className="flex items-center">
            <Button 
              type="text" 
              icon={<ArrowLeftOutlined />} 
              onClick={() => setUserData(null)}
              className="mr-2"
            />
            User Credit Data
          </div>
        }
        className="shadow-lg"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          {/* User Information */}
          <Card title="User Information" className="col-span-1">
            <div className="space-y-4">
              <div>
                <div className="text-sm text-gray-500">Name</div>
                <div className="font-medium">
                  {userData.user?.name || <span className="text-gray-400">Not provided</span>}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-500">Email</div>
                <div>{userData.user?.email || <span className="text-gray-400">Not provided</span>}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500">Role</div>
                <Tag color={userData.user?.role === 'admin' ? 'gold' : 'blue'} className="capitalize">
                  {userData.user?.role || 'user'}
                </Tag>
              </div>
              <div>
                <div className="text-sm text-gray-500">Account Status</div>
                <Tag color={userData.user?.isActive !== false ? 'success' : 'default'}>
                  {userData.user?.isActive !== false ? 'Active' : 'Inactive'}
                </Tag>
              </div>
              <div>
                <div className="text-sm text-gray-500">Member Since</div>
                <div>{userData.user?.createdAt ? formatDate(userData.user.createdAt) : 'N/A'}</div>
              </div>
            </div>
          </Card>

          {/* Credit Score Summary */}
          <Card title="Credit Score" className="col-span-1">
            {userData.currentScore !== undefined ? (
              <div className="text-center">
                <div 
                  className="mx-auto w-32 h-32 rounded-full flex items-center justify-center text-white text-3xl font-bold mb-4"
                  style={{
                    background: `linear-gradient(135deg, ${userData.currentScore >= 700 ? '#52c41a' : userData.currentScore >= 600 ? '#faad14' : '#f5222d'}, ${userData.currentScore >= 700 ? '#73d13d' : userData.currentScore >= 600 ? '#ffc53d' : '#ff4d4f'})`,
                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
                  }}
                >
                  {Math.round(userData.currentScore)}
                </div>
                <div className="text-lg font-medium mb-2">
                  {userData.currentScore >= 700 ? 'Excellent' : userData.currentScore >= 600 ? 'Good' : 'Needs Improvement'}
                </div>
                <div className="text-sm text-gray-500">
                  {userData.creditScores?.length > 0 ? (
                    <span>Last updated {formatDate(userData.creditScores[0]?.date)}</span>
                  ) : 'No update history'}
                </div>
              </div>
            ) : (
              <div className="text-center py-4 text-gray-400">No credit score available</div>
            )}
          </Card>

          {/* Credit Factors */}
          <Card title="Credit Factors" className="col-span-1">
            {userData.factors?.length > 0 ? (
              <div className="space-y-4">
                {userData.factors.map((factor, index) => (
                  <div key={index}>
                    <div className="flex justify-between text-sm mb-1">
                      <span>{factor.name}</span>
                      <span className="font-medium">{factor.score}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="h-2 rounded-full"
                        style={{
                          width: `${Math.min(100, factor.score)}%`,
                          backgroundColor: factor.score >= 70 ? '#52c41a' : factor.score >= 40 ? '#faad14' : '#f5222d'
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4 text-gray-400">No credit factors available</div>
            )}
          </Card>
        </div>

        <Card title="Credit Score History" className="mt-6">
          <Table 
            dataSource={userData.creditScores?.map((record, index) => ({
              ...record,
              key: record.date || `record-${index}`,
              // Ensure we have a valid date for sorting
              sortableDate: record.date ? new Date(record.date) : new Date(0)
            }))} 
            columns={[
              {
                title: 'Date',
                dataIndex: 'date',
                key: 'date',
                render: (date) => date ? formatDate(date) : 'N/A',
                sorter: (a, b) => (a.sortableDate - b.sortableDate),
                defaultSortOrder: 'descend',
                width: 200,
              },
              {
                title: 'Score',
                dataIndex: 'score',
                key: 'score',
                render: (score) => {
                  if (score === undefined || score === null) return 'N/A';
                  const displayScore = Math.min(Math.round(score), 999);
                  const color = score >= 700 ? '#52c41a' : score >= 600 ? '#faad14' : '#f5222d';
                  
                  return (
                    <div className="flex items-center">
                      <div 
                        style={{
                          backgroundColor: color,
                          width: '40px',
                          height: '40px',
                          borderRadius: '50%',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          color: 'white',
                          fontWeight: 'bold',
                          marginRight: '8px'
                        }}
                      >
                        {displayScore}
                      </div>
                      <div>
                        <div className="font-medium">{displayScore}</div>
                        <div className="text-xs text-gray-500">
                          {score >= 700 ? 'Excellent' : score >= 600 ? 'Good' : 'Needs Improvement'}
                        </div>
                      </div>
                    </div>
                  );
                },
                sorter: (a, b) => (a.score || 0) - (b.score || 0),
                width: 200,
              },
              {
                title: 'Change',
                key: 'change',
                render: (_, record, index) => {
                  if (index === 0 || !userData.creditScores?.[index - 1]?.score) return 'N/A';
                  const change = record.score - userData.creditScores[index - 1].score;
                  const isPositive = change >= 0;
                  const changeText = isPositive ? `+${change}` : change;
                  
                  return (
                    <span className={`inline-flex items-center ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
                      {isPositive ? (
                        <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                        </svg>
                      ) : (
                        <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                      )}
                      {changeText} pts
                    </span>
                  );
                },
                width: 150,
              },
              {
                title: 'Status',
                key: 'status',
                render: (_, record) => {
                  const score = record.score || 0;
                  let status, color;
                  
                  if (score >= 700) {
                    status = 'Excellent';
                    color = 'success';
                  } else if (score >= 600) {
                    status = 'Good';
                    color = 'warning';
                  } else {
                    status = 'Needs Improvement';
                    color = 'error';
                  }
                  
                  return <Tag color={color} className="capitalize">{status}</Tag>;
                },
                filters: [
                  { text: 'Excellent (700+)', value: 'excellent' },
                  { text: 'Good (600-699)', value: 'good' },
                  { text: 'Needs Improvement (<600)', value: 'needs_improvement' },
                ],
                onFilter: (value, record) => {
                  const score = record.score || 0;
                  if (value === 'excellent') return score >= 700;
                  if (value === 'good') return score >= 600 && score < 700;
                  return score < 600;
                },
                width: 180,
              },
            ]}
            rowKey="key"
            loading={loading}
            pagination={{ pageSize: 5 }}
            className="shadow-sm"
            locale={{
              emptyText: 'No credit score history available'
            }}
          />
        </Card>
      </Card>
    );
  }

  return (
    <Card 
      title={
        <div className="flex items-center">
          <UserOutlined className="mr-2" />
          View User Credit Data
        </div>
      }
      className="max-w-2xl mx-auto shadow-lg"
    >
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Enter User ID
          </label>
          <div className="flex space-x-2">
            <Input
              placeholder="User ID"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              onPressEnter={fetchUserData}
              className="flex-1"
            />
            <Button 
              type="primary" 
              icon={<SearchOutlined />} 
              onClick={fetchUserData}
              loading={loading}
            >
              Search
            </Button>
          </div>
        </div>
        <p className="text-sm text-gray-500">
          Enter the user's ID to view their credit score history and account details.
        </p>
      </div>
    </Card>
  );
};

export default UserDataViewer;
