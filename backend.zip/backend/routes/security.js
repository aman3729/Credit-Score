import express from 'express';
import crypto from 'crypto';
import { auth } from '../middleware/auth.js';
import User from '../models/User.js';
import { generateTwoFactorSecret, verifyTwoFactorToken } from '../config/auth.js';
import { sendEmail, emailTemplates } from '../config/email.js';

const router = express.Router();

// Enable 2FA
router.post('/2fa/enable', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (user.twoFactorEnabled) {
      return res.status(400).json({ error: '2FA is already enabled' });
    }

    const { secret, qrCode } = await generateTwoFactorSecret(user.email);
    
    user.twoFactorSecret = secret;
    await user.save();

    res.json({
      message: '2FA setup initiated',
      qrCode,
      secret
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to enable 2FA' });
  }
});

// Verify and activate 2FA
router.post('/2fa/verify', auth, async (req, res) => {
  try {
    const { token } = req.body;
    const user = await User.findById(req.user.userId);

    if (!user || !user.twoFactorSecret) {
      return res.status(400).json({ error: '2FA not set up' });
    }

    const isValid = verifyTwoFactorToken(user.twoFactorSecret, token);
    if (!isValid) {
      return res.status(400).json({ error: 'Invalid 2FA token' });
    }

    user.twoFactorEnabled = true;
    await user.save();

    res.json({ message: '2FA enabled successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to verify 2FA' });
  }
});

// Disable 2FA
router.post('/2fa/disable', auth, async (req, res) => {
  try {
    const { token } = req.body;
    const user = await User.findById(req.user.userId);

    if (!user || !user.twoFactorEnabled) {
      return res.status(400).json({ error: '2FA is not enabled' });
    }

    const isValid = verifyTwoFactorToken(user.twoFactorSecret, token);
    if (!isValid) {
      return res.status(400).json({ error: 'Invalid 2FA token' });
    }

    user.twoFactorEnabled = false;
    user.twoFactorSecret = null;
    await user.save();

    res.json({ message: '2FA disabled successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to disable 2FA' });
  }
});

// Request password reset
router.post('/password/reset-request', async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const resetToken = crypto.randomBytes(32).toString('hex');
    const hashedToken = crypto
      .createHash('sha256')
      .update(resetToken)
      .digest('hex');

    user.passwordResetToken = hashedToken;
    user.passwordResetExpires = Date.now() + 3600000; // 1 hour
    await user.save();

    // Send password reset email
    await sendEmail({
      to: user.email,
      ...emailTemplates.passwordReset(resetToken)
    });

    res.json({ message: 'Password reset email sent' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to process password reset request' });
  }
});

// Reset password
router.post('/password/reset', async (req, res) => {
  try {
    const { token, newPassword } = req.body;
    const hashedToken = crypto
      .createHash('sha256')
      .update(token)
      .digest('hex');

    const user = await User.findOne({
      passwordResetToken: hashedToken,
      passwordResetExpires: { $gt: Date.now() }
    });

    if (!user) {
      return res.status(400).json({ error: 'Invalid or expired reset token' });
    }

    user.password = newPassword;
    user.passwordResetToken = undefined;
    user.passwordResetExpires = undefined;
    await user.save();

    res.json({ message: 'Password reset successful' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to reset password' });
  }
});

// Update notification preferences
router.put('/notifications/preferences', auth, async (req, res) => {
  try {
    const { email, push } = req.body;
    const user = await User.findById(req.user.userId);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (email) {
      user.notificationPreferences.email = {
        ...user.notificationPreferences.email,
        ...email
      };
    }

    if (push) {
      user.notificationPreferences.push = {
        ...user.notificationPreferences.push,
        ...push
      };
    }

    await user.save();
    res.json({
      message: 'Notification preferences updated',
      preferences: user.notificationPreferences
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update notification preferences' });
  }
});

// Register device
router.post('/devices/register', auth, async (req, res) => {
  try {
    const { deviceId, deviceName } = req.body;
    const user = await User.findById(req.user.userId);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const existingDevice = user.devices.find(d => d.deviceId === deviceId);
    if (existingDevice) {
      existingDevice.lastUsed = new Date();
      existingDevice.deviceName = deviceName;
    } else {
      user.devices.push({
        deviceId,
        deviceName,
        lastUsed: new Date(),
        trusted: false
      });
    }

    await user.save();
    res.json({ message: 'Device registered successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to register device' });
  }
});

export default router; 