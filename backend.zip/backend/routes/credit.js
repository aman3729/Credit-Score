const express = require('express')
const router = express.Router()

router.get('/', (req, res) => {
  res.json({
    score: 745,
    status: 'Good',
    recommendation: 'Maintain low credit utilization and keep old accounts open.',
    history: [
      { month: 'Jan', score: 720 },
      { month: 'Feb', score: 730 },
      { month: 'Mar', score: 735 },
      { month: 'Apr', score: 740 },
      { month: 'May', score: 745 }
    ]
  })
})

module.exports = router