import winston from 'winston';
import 'winston-daily-rotate-file';
import path from 'path';

const { combine, timestamp, json, printf, colorize, align } = winston.format;

// Custom format for console output
const consoleFormat = printf(({ level, message, timestamp, ...metadata }) => {
  const metaStr = Object.keys(metadata).length ? JSON.stringify(metadata, null, 2) : '';
  return `${timestamp} [${level}]: ${message} ${metaStr}`;
});

// Create the logger
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: combine(
    timestamp(),
    json()
  ),
  transports: [
    // Console transport with colors (for development)
    new winston.transports.Console({
      format: combine(
        colorize(),
        align(),
        consoleFormat
      )
    }),
    
    // Daily rotate file for all logs
    new winston.transports.DailyRotateFile({
      filename: path.join('logs', 'application-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      maxSize: '20m',
      maxFiles: '14d',
      format: combine(
        timestamp(),
        json()
      )
    }),

    // Separate file for security events
    new winston.transports.DailyRotateFile({
      filename: path.join('logs', 'security-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      maxSize: '20m',
      maxFiles: '30d',
      format: combine(
        timestamp(),
        json()
      ),
      level: 'warn' // Only log warning and above for security events
    })
  ]
});

// Create a separate security logger
const securityLogger = {
  log: (level, message, meta = {}) => {
    logger.log({
      level,
      message,
      ...meta,
      category: 'security'
    });
  },
  warn: (message, meta = {}) => {
    logger.warn(message, { ...meta, category: 'security' });
  },
  error: (message, meta = {}) => {
    logger.error(message, { ...meta, category: 'security' });
  },
  info: (message, meta = {}) => {
    logger.info(message, { ...meta, category: 'security' });
  }
};

export { logger, securityLogger }; 