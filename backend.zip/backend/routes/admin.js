import express from 'express';
import User from '../models/User.js';
import UserScore from '../models/UserScore.js';
import { auth, requireAdmin } from '../middleware/auth.js';
import fs from 'fs/promises';
import path from 'path';
import { createReadStream } from 'fs';
import { createGunzip } from 'zlib';
import { pipeline } from 'stream/promises';
import { createWriteStream } from 'fs';
import { logArchiver } from '../services/logArchiver.js';
import { alertService } from '../services/alertService.js';

const router = express.Router();

// Get all users with their credit scores
router.get('/users', auth, requireAdmin, async (req, res) => {
  try {
    const users = await User.find().select('-password');
    const userScores = await UserScore.find();

    const usersWithScores = users.map(user => {
      const creditScore = userScores.find(score => score.userId === user._id.toString());
      return {
        ...user.toObject(),
        creditScore,
        active: user.lastLogin > new Date(Date.now() - 24 * 60 * 60 * 1000) // Active in last 24h
      };
    });

    res.json(usersWithScores);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching users' });
  }
});

// Delete user
router.delete('/users/:userId', auth, requireAdmin, async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.userId);
    await UserScore.findOneAndDelete({ userId: req.params.userId });
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error deleting user' });
  }
});

// Get user details
router.get('/users/:userId', auth, requireAdmin, async (req, res) => {
  try {
    const user = await User.findById(req.params.userId).select('-password');
    const creditScore = await UserScore.findOne({ userId: req.params.userId });
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      ...user.toObject(),
      creditScore
    });
  } catch (error) {
    res.status(500).json({ error: 'Error fetching user details' });
  }
});

// Update user role
router.patch('/users/:userId/role', auth, requireAdmin, async (req, res) => {
  try {
    const { role } = req.body;
    if (!['user', 'admin'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role' });
    }

    const user = await User.findByIdAndUpdate(
      req.params.userId,
      { role },
      { new: true }
    ).select('-password');

    res.json(user);
  } catch (error) {
    res.status(500).json({ error: 'Error updating user role' });
  }
});

// Promote user to admin
router.post('/promote/:userId', auth, requireAdmin, async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.userId,
      { role: 'admin' },
      { new: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      message: 'User promoted to admin successfully',
      user
    });
  } catch (error) {
    res.status(500).json({ error: 'Error promoting user to admin' });
  }
});

// Get security logs
router.get('/security-logs', auth, requireAdmin, async (req, res) => {
  try {
    const { date = new Date().toISOString().split('T')[0], archived = false } = req.query;
    
    if (archived) {
      // Get archived log
      const archivePath = await logArchiver.getArchivedLog(date);
      
      if (!archivePath) {
        return res.json([]); // No archived logs for this date
      }

      // Create temporary file for decompressed content
      const tempFile = path.join(process.cwd(), 'temp', `temp-${Date.now()}.log`);
      await fs.mkdir(path.dirname(tempFile), { recursive: true });

      // Decompress the file
      await pipeline(
        createReadStream(archivePath),
        createGunzip(),
        createWriteStream(tempFile)
      );

      // Read and parse the decompressed content
      const content = await fs.readFile(tempFile, 'utf-8');
      
      // Clean up temporary file
      await fs.unlink(tempFile);

      const logs = content
        .split('\n')
        .filter(Boolean)
        .map(line => JSON.parse(line))
        .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

      res.json(logs);
    } else {
      // Fetch from local filesystem
      const logFile = path.join('logs', `security-${date}.log`);
      try {
        const content = await fs.readFile(logFile, 'utf-8');
        const logs = content
          .split('\n')
          .filter(Boolean)
          .map(line => JSON.parse(line))
          .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

        res.json(logs);
      } catch (error) {
        if (error.code === 'ENOENT') {
          res.json([]); // No logs for this date
        } else {
          throw error;
        }
      }
    }
  } catch (error) {
    console.error('Error fetching security logs:', error);
    res.status(500).json({ error: 'Failed to fetch security logs' });
  }
});

// Get security stats
router.get('/security-stats', auth, requireAdmin, async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const logFile = path.join('logs', `security-${today}.log`);
    
    try {
      const content = await fs.readFile(logFile, 'utf-8');
      const logs = content
        .split('\n')
        .filter(Boolean)
        .map(line => JSON.parse(line));

      const stats = {
        totalEvents: logs.length,
        byType: {},
        bySeverity: {},
        suspiciousIPs: new Set(),
        recentEvents: logs.slice(-10)
      };

      logs.forEach(log => {
        // Count by type
        stats.byType[log.message] = (stats.byType[log.message] || 0) + 1;
        
        // Count by severity
        stats.bySeverity[log.level] = (stats.bySeverity[log.level] || 0) + 1;
        
        // Track suspicious IPs
        if (log.ip) {
          stats.suspiciousIPs.add(log.ip);
        }
      });

      // Convert Set to Array for JSON serialization
      stats.suspiciousIPs = Array.from(stats.suspiciousIPs);

      res.json(stats);
    } catch (error) {
      if (error.code === 'ENOENT') {
        res.json({
          totalEvents: 0,
          byType: {},
          bySeverity: {},
          suspiciousIPs: [],
          recentEvents: []
        });
      } else {
        throw error;
      }
    }
  } catch (error) {
    console.error('Error fetching security stats:', error);
    res.status(500).json({ error: 'Failed to fetch security stats' });
  }
});

// Acknowledge security alert
router.post('/alerts/:alertId/acknowledge', auth, requireAdmin, async (req, res) => {
  try {
    const { alertId } = req.params;
    const adminId = req.user.userId;

    const acknowledgment = await alertService.acknowledgeAlert(alertId, adminId);
    
    if (acknowledgment) {
      res.json({ message: 'Alert acknowledged successfully', acknowledgment });
    } else {
      res.status(400).json({ error: 'Alert already acknowledged' });
    }
  } catch (error) {
    console.error('Error acknowledging alert:', error);
    res.status(500).json({ error: 'Failed to acknowledge alert' });
  }
});

// Get alert acknowledgment status
router.get('/alerts/:alertId/acknowledgment', auth, requireAdmin, async (req, res) => {
  try {
    const { alertId } = req.params;
    const acknowledgment = alertService.getAlertAcknowledgment(alertId);
    
    if (acknowledgment) {
      res.json(acknowledgment);
    } else {
      res.status(404).json({ error: 'Alert not acknowledged' });
    }
  } catch (error) {
    console.error('Error getting alert acknowledgment:', error);
    res.status(500).json({ error: 'Failed to get alert acknowledgment' });
  }
});

export default router; 