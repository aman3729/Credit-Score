import express from 'express';
import { auth, requireAdmin } from '../middleware/auth.js';
import CreditReport from '../models/CreditReport.js';
import User from '../models/User.js';

const router = express.Router();

// Get credit report for a specific user
router.get('/credit-report/:userId', auth, requireAdmin, async (req, res) => {
  try {
    const creditReport = await CreditReport.findOne({ userId: req.params.userId });
    if (!creditReport) {
      return res.status(404).json({ error: 'Credit report not found' });
    }
    res.json(creditReport);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching credit report' });
  }
});

// Get summarized credit report (for quick decisions)
router.get('/quick-report/:userId', auth, requireAdmin, async (req, res) => {
  try {
    const creditReport = await CreditReport.findOne({ userId: req.params.userId });
    if (!creditReport) {
      return res.status(404).json({ error: 'Credit report not found' });
    }

    // Calculate key metrics
    const totalAccounts = creditReport.creditAccounts.length;
    const openAccounts = creditReport.creditAccounts.filter(acc => acc.status === 'open').length;
    const totalBalance = creditReport.creditAccounts.reduce((sum, acc) => sum + acc.balance, 0);
    const recentInquiries = creditReport.inquiries.filter(
      inq => new Date() - inq.date < 90 * 24 * 60 * 60 * 1000 // Last 90 days
    ).length;

    // Get delinquencies in last 24 months
    const delinquencies = creditReport.creditAccounts.reduce((count, account) => {
      const recentLatePayments = account.paymentHistory.filter(payment => 
        payment.status !== 'on_time' && 
        new Date() - payment.date < 24 * 30 * 24 * 60 * 60 * 1000
      ).length;
      return count + recentLatePayments;
    }, 0);

    res.json({
      ficoScore: creditReport.creditScore.fico,
      vantageScore: creditReport.creditScore.vantageScore,
      creditUtilization: creditReport.creditUtilization.overall,
      accountSummary: {
        total: totalAccounts,
        open: openAccounts,
        totalBalance
      },
      delinquencies,
      recentInquiries,
      creditAge: creditReport.creditAge,
      riskFactors: creditReport.riskFactors,
      fraudAlerts: creditReport.fraudAlerts,
      debtToIncome: creditReport.debtToIncome
    });
  } catch (error) {
    res.status(500).json({ error: 'Error fetching quick report' });
  }
});

// Get automated decision recommendation
router.post('/decision/:userId', auth, requireAdmin, async (req, res) => {
  try {
    const { loanType, loanAmount, interestRate } = req.body;
    const creditReport = await CreditReport.findOne({ userId: req.params.userId });
    
    if (!creditReport) {
      return res.status(404).json({ error: 'Credit report not found' });
    }

    // Calculate monthly payment (simplified)
    const termMonths = 60; // Example: 5-year loan
    const monthlyPayment = (loanAmount * (interestRate / 12)) / 
      (1 - Math.pow(1 + (interestRate / 12), -termMonths));

    // Decision logic
    const decision = {
      approved: false,
      reasons: [],
      conditions: [],
      suggestedTerms: null
    };

    // Basic approval criteria
    if (creditReport.creditScore.fico.score >= 680 &&
        creditReport.debtToIncome.ratio <= 0.43 &&
        creditReport.creditUtilization.overall <= 70) {
      decision.approved = true;
    }

    // Add decision reasons
    if (creditReport.creditScore.fico.score < 680) {
      decision.reasons.push('Credit score below required minimum');
    }
    if (creditReport.debtToIncome.ratio > 0.43) {
      decision.reasons.push('Debt-to-income ratio too high');
    }
    if (creditReport.creditUtilization.overall > 70) {
      decision.reasons.push('Credit utilization too high');
    }

    // Add conditions for approval
    if (decision.approved) {
      if (creditReport.creditScore.fico.score < 720) {
        decision.conditions.push('Higher down payment required');
        decision.conditions.push('Collateral may be required');
      }
      if (creditReport.debtToIncome.ratio > 0.35) {
        decision.conditions.push('Proof of additional income required');
      }

      // Suggest modified terms if needed
      if (creditReport.creditScore.fico.score < 700) {
        decision.suggestedTerms = {
          interestRate: interestRate + 0.02, // Add 2% for higher risk
          downPayment: loanAmount * 0.20, // 20% down payment
          term: termMonths
        };
      } else {
        decision.suggestedTerms = {
          interestRate,
          downPayment: loanAmount * 0.10, // 10% down payment
          term: termMonths
        };
      }
    }

    res.json({
      decision,
      creditScore: creditReport.creditScore.fico.score,
      debtToIncome: creditReport.debtToIncome.ratio,
      monthlyPayment,
      riskFactors: creditReport.riskFactors
    });
  } catch (error) {
    res.status(500).json({ error: 'Error generating decision' });
  }
});

// Get fraud and identity verification
router.get('/fraud-check/:userId', auth, requireAdmin, async (req, res) => {
  try {
    const creditReport = await CreditReport.findOne({ userId: req.params.userId });
    if (!creditReport) {
      return res.status(404).json({ error: 'Credit report not found' });
    }

    // Check for suspicious patterns
    const suspiciousActivity = {
      alerts: creditReport.fraudAlerts,
      addressDiscrepancies: creditReport.personalInfo.addresses.length > 3,
      rapidInquiries: creditReport.inquiries.filter(
        inq => new Date() - inq.date < 30 * 24 * 60 * 60 * 1000
      ).length > 5,
      identityVerified: true // This should come from a real identity verification service
    };

    res.json(suspiciousActivity);
  } catch (error) {
    res.status(500).json({ error: 'Error checking fraud alerts' });
  }
});

export default router; 